# Twoje nagrania treningowe

Dodawaj filmy lub oryginalne CSV przez **opcję 10** w `python launcher.py`. Program sam tworzy katalogi `prawidlowy/ID_PSA/` oraz `nieprawidlowy/ID_PSA/` i zapisuje punkty. Dla tego samego psa zawsze podawaj to samo ID.

Po dodaniu co najmniej dwóch różnych nagrań w każdej klasie uruchom trening **opcją 11**. Następnie oceniaj nowe nagrania **opcją 12**. Po dodaniu dalszych przykładów ponownie wykonaj trening.

Ten katalog celowo nie zawiera przykładów z nadanymi z góry etykietami. Dołączony film demonstracyjny nie ma zweryfikowanej etykiety dobrego/złego ruchu. Szczegółowa instrukcja: [docs/TRAINING.md](../docs/TRAINING.md).
