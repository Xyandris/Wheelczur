"""A supervised, persistent normal/abnormal motion classifier.

User-provided recording labels are the targets. Training uses standardized
kinematic features and regularized logistic regression; inference uses NumPy
and a validated JSON model, without deserializing executable Python objects.
"""

from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
import json
import math
import os
import tempfile
import warnings

import numpy as np

from . import __version__
from .motion import MotionConfig, analyze_tracking
from .runtime import TrackingError
from .schema import LIMBS, selected_limbs


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_DATASET = ROOT / "training_data"
DEFAULT_MODEL = ROOT / "gait_model.json"
LABELS = ("prawidlowy", "nieprawidlowy")
MODEL_FORMAT = "wheelczur_supervised_gait"
FEATURE_VERSION = 1
DESCRIPTORS = (
    "angle_mean", "angle_range", "angular_speed_mean", "angular_speed_p95",
    "paw_x_range", "paw_y_range", "paw_speed_mean", "paw_speed_p95", "paw_speed_cv",
)


class FeatureError(TrackingError):
    """The recording cannot support a comparable motion feature vector."""


def feature_names(limb):
    names = [f"{name}/{descriptor}" for name in selected_limbs(limb) for descriptor in DESCRIPTORS]
    if limb == "all":
        names += [f"{pair}/{descriptor}" for pair in ("fore", "hind")
                  for descriptor in ("angle_difference", "paw_x_difference")]
    return names


def features_from_csv(path, limb="all", settings=None, fps=None):
    if limb not in (*LIMBS, "all"):
        raise TrackingError("Nieznana konczyna modelu.")
    settings = settings or {"min_confidence": 0.0, "smooth_ms": 100.0}
    config = MotionConfig(settings["min_confidence"], settings["smooth_ms"], fps)
    report, rows = analyze_tracking(path, config)
    speeds = {name: [] for name in selected_limbs(limb)}
    for row in rows:
        speed = row["relative_paw_speed_limb_lengths_s"]
        if row["limb"] in speeds and speed is not None:
            speeds[row["limb"]].append(speed)
    values, moving = [], False
    for name in selected_limbs(limb):
        item = report["limbs"].get(name)
        if item is None:
            raise FeatureError(f"Brak punktow {name}. Model wymaga: {limb}. Wykonaj sledzenie z --limb {limb}.")
        if item["quality"] != "usable":
            raise FeatureError(f"{name}: za malo dobrych punktow (pokrycie {item['coverage']:.0%}). "
                               "Potrzeba co najmniej sekundy obserwacji i 60% pokrycia.")
        angle, angular = item["joint_angle_deg"], item["angular_speed_deg_s"]
        px, py = item["relative_paw_x_limb_lengths"], item["relative_paw_y_limb_lengths"]
        speed = item["relative_paw_speed_limb_lengths_s"]
        if any(stat is None for stat in (angle, angular, px, py, speed)) or not speeds[name]:
            raise FeatureError(f"{name}: brak ciaglego odcinka do pomiaru predkosci.")
        moving |= angle["range_p05_p95"] >= 3 or max(px["range_p05_p95"], py["range_p05_p95"]) >= 0.01
        average = float(np.mean(speeds[name]))
        values.extend((angle["mean"] / 180, angle["range_p05_p95"] / 180,
                       angular["mean"] / 180, angular["p95"] / 180,
                       px["range_p05_p95"], py["range_p05_p95"], speed["mean"], speed["p95"],
                       float(np.std(speeds[name])) / average if average > 1e-8 else 0.0))
    if not moving:
        raise FeatureError("Brak wystarczajacego ruchu konczyn. Wybierz nagranie poruszajacego sie psa.")
    if limb == "all":
        for pair in ("fore", "hind"):
            comparison = report["symmetry"][pair]
            if comparison["status"] != "ok":
                raise FeatureError(f"{pair}: za malo wspolnych obserwacji lewej i prawej strony.")
            # A zero range on both sides is a zero difference, not an unknown feature.
            values.extend(((comparison["angle_range_relative_difference_pct"] or 0.0) / 200,
                           (comparison["paw_x_excursion_relative_difference_pct"] or 0.0) / 200))
    vector = np.asarray(values, dtype=float)
    if not np.isfinite(vector).all():
        raise FeatureError("Nie mozna wyznaczyc skonczonych cech ruchu.")
    return vector, report


def _fit(features, targets):
    from sklearn.exceptions import ConvergenceWarning
    from sklearn.linear_model import LogisticRegression
    from sklearn.preprocessing import StandardScaler
    scaler = StandardScaler().fit(features)
    classifier = LogisticRegression(C=1.0, class_weight="balanced", solver="lbfgs",
                                    max_iter=2000, random_state=0)
    with warnings.catch_warnings():
        warnings.simplefilter("error", ConvergenceWarning)
        try:
            classifier.fit(scaler.transform(features), targets)
        except ConvergenceWarning as exc:
            raise TrackingError("Trening nie osiagnal zbieznosci; sprawdz dane treningowe.") from exc
    return {"mean": scaler.mean_.tolist(), "scale": scaler.scale_.tolist(),
            "weights": classifier.coef_[0].tolist(), "intercept": float(classifier.intercept_[0])}


def model_scores(parameters, features):
    features = np.asarray(features, dtype=float)
    standardized = (features - np.asarray(parameters["mean"])) / np.asarray(parameters["scale"])
    logits = standardized @ np.asarray(parameters["weights"]) + parameters["intercept"]
    return np.exp(-np.logaddexp(0, -logits))


def _metrics(targets, predictions):
    confusion = np.zeros((2, 2), dtype=int)
    for true, predicted in zip(targets, predictions):
        confusion[int(true), int(predicted)] += 1
    recall = np.diag(confusion) / np.maximum(confusion.sum(axis=1), 1)
    return {"accuracy": float(np.mean(np.asarray(targets) == predictions)),
            "balanced_accuracy": float(recall.mean()), "confusion_matrix": confusion.tolist(),
            "recall": {label: float(recall[i]) for i, label in enumerate(LABELS)},
            "class_order": list(LABELS)}


def grouped_validation(features, targets, groups):
    """Hold every dog's recordings together; fit the scaler inside each fold."""
    from sklearn.model_selection import GroupKFold
    unique = sorted(set(groups))
    if len(unique) < 2:
        return {"status": "insufficient_dogs", "metrics": None, "evaluated_samples": 0, "folds": []}
    groups = np.asarray(groups)
    predictions = np.full(len(targets), -1, dtype=int)
    folds = []
    for train, test in GroupKFold(n_splits=min(5, len(unique))).split(features, targets, groups):
        fold = {"train_dogs": sorted(set(groups[train].tolist())),
                "test_dogs": sorted(set(groups[test].tolist())), "test_samples": len(test)}
        if len(np.unique(targets[train])) < 2:
            fold["status"] = "training_fold_missing_class"
        else:
            parameters = _fit(features[train], targets[train])
            predictions[test] = model_scores(parameters, features[test]) >= 0.5
            fold["status"] = "ok"
        folds.append(fold)
    complete = bool(np.all(predictions >= 0))
    return {"status": "ok" if complete else "insufficient_class_distribution_by_dog",
            "metrics": _metrics(targets, predictions) if complete else None,
            "evaluated_samples": int((predictions >= 0).sum()), "folds": folds,
            "method": "GroupKFold by dog_id; no dog appears in both sides of a fold"}


def _atomic_json(path, data):
    path = Path(path)
    if path.exists() and not path.is_file():
        raise TrackingError(f"Sciezka modelu nie jest plikiem: {path}")
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix=".gait-model-", dir=path.parent) as temporary:
        staged = Path(temporary) / "model.json"
        staged.write_text(json.dumps(data, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
        os.replace(staged, path)


def train_classifier(dataset=DEFAULT_DATASET, model_path=DEFAULT_MODEL, limb="all", settings=None,
                     tracking_options=None, progress=None):
    from .dataset import collect_samples, prepare_tracking_csv, sha256
    settings = settings or {"min_confidence": 0.0, "smooth_ms": 100.0}
    MotionConfig(settings["min_confidence"], settings["smooth_ms"]).validate()
    if limb not in (*LIMBS, "all"):
        raise TrackingError("Nieznana konczyna modelu.")
    dataset = Path(dataset).expanduser().resolve()
    model_path = Path(model_path).expanduser().resolve()
    samples = collect_samples(dataset)
    raw_counts = Counter(sample["label"] for sample in samples)
    if any(raw_counts[label] < 2 for label in LABELS):
        raise TrackingError("Potrzeba co najmniej 2 ROZNYCH nagran prawidlowych i 2 nieprawidlowych. "
                            "Dodaj przyklady opcja 10, a potem ponow trening.")
    features, labels, groups, manifest, skipped = [], [], [], [], []
    seen = {}
    for i, sample in enumerate(samples, 1):
        if progress:
            progress(f"Przygotowanie {i}/{len(samples)}: {sample['path'].name}")
        source = sample["path"]
        source_hash = sha256(source)
        csv_path = prepare_tracking_csv(source, dataset / ".cache", limb, tracking_options, progress)
        csv_hash = sha256(csv_path)
        if csv_hash in seen:
            previous = seen[csv_hash]
            if previous["label"] != sample["label"]:
                raise TrackingError(f"To samo nagranie ma sprzeczne etykiety: {previous['source']} oraz {source}.")
            skipped.append(str(source.relative_to(dataset)))
            continue
        try:
            vector, _ = features_from_csv(csv_path, limb, settings)
        except (TrackingError, ValueError, OSError) as exc:
            raise TrackingError(f"Nie mozna uzyc przykladu {source}: {exc}") from exc
        record = {"source": str(source.relative_to(dataset)), "label": sample["label"],
                  "dog_id": sample["dog_id"], "source_sha256": source_hash, "tracking_sha256": csv_hash}
        seen[csv_hash] = record
        features.append(vector)
        labels.append(LABELS.index(sample["label"]))
        groups.append(sample["dog_id"])
        manifest.append(record)
    counts = Counter(labels)
    if any(counts[i] < 2 for i in range(2)):
        raise TrackingError("Potrzeba co najmniej 2 ROZNYCH nagran prawidlowych i 2 nieprawidlowych. "
                            "Kopie tego samego CSV nie sa nowymi przykladami.")
    matrix, targets = np.stack(features), np.asarray(labels, dtype=int)
    if float(np.ptp(matrix, axis=0).max()) < 1e-8:
        raise TrackingError("Wszystkie przyklady maja identyczne cechy ruchu; nie mozna nauczyc rozroznienia.")
    validation = grouped_validation(matrix, targets, groups)
    parameters = _fit(matrix, targets)
    if np.linalg.norm(parameters["weights"]) < 1e-8:
        raise TrackingError("Nie znaleziono sygnalu odrozniajacego etykiety. Sprawdz przyklady i ich oznaczenia.")
    notes = []
    if validation["status"] != "ok":
        notes.append("Brak pelnej niezaleznej walidacji na innych psach. Dodaj wiecej psow w obu klasach.")
    if min(counts.values()) < 10:
        notes.append("Maly zbior treningowy: wynik jest prototypowa ocena wzgledem dostarczonych etykiet.")
    model = {
        "format": MODEL_FORMAT, "model_version": 1, "feature_version": FEATURE_VERSION,
        "program_version": __version__, "created_utc": datetime.now(timezone.utc).isoformat(),
        "limb": limb, "classes": list(LABELS), "features": feature_names(limb),
        "motion_settings": settings, "parameters": parameters, "decision_confidence": 0.6,
        "training": {"samples": len(labels), "dogs": len(set(groups)),
                     "class_counts": {label: counts[i] for i, label in enumerate(LABELS)},
                     "manifest": manifest, "skipped_duplicates": skipped, "validation": validation,
                     "resubstitution_metrics": _metrics(targets, model_scores(parameters, matrix) >= 0.5),
                     "notes": notes},
        "interpretation": "Classification learned from user labels; not a veterinary diagnosis.",
    }
    # Validate the same representation that inference will load before replacing a good model.
    validate_model(model)
    if model_path in {item["path"].resolve() for item in samples}:
        raise TrackingError("Nie zapisuj modelu pod sciezka nagrania treningowego.")
    _atomic_json(model_path, model)
    return model


def validate_model(model):
    try:
        if (model["format"] != MODEL_FORMAT or model["model_version"] != 1
                or model["feature_version"] != FEATURE_VERSION or model["classes"] != list(LABELS)):
            raise ValueError("nieobslugiwany format lub wersja")
        limb = model["limb"]
        if limb not in (*LIMBS, "all") or model["features"] != feature_names(limb):
            raise ValueError("niezgodny schemat cech")
        size, parameters = len(model["features"]), model["parameters"]
        for key in ("mean", "scale", "weights"):
            array = np.asarray(parameters[key], dtype=float)
            if array.shape != (size,) or not np.isfinite(array).all():
                raise ValueError(f"niepoprawny parametr {key}")
            parameters[key] = array.tolist()
        if np.any(np.asarray(parameters["scale"]) <= 0):
            raise ValueError("skala musi byc dodatnia")
        if not math.isfinite(float(parameters["intercept"])):
            raise ValueError("niepoprawny wyraz wolny")
        parameters["intercept"] = float(parameters["intercept"])
        threshold = float(model["decision_confidence"])
        if not math.isfinite(threshold) or not 0.5 <= threshold <= 1:
            raise ValueError("niepoprawny prog decyzji")
        model["decision_confidence"] = threshold
        settings = model["motion_settings"]
        MotionConfig(float(settings["min_confidence"]), float(settings["smooth_ms"])).validate()
        model["motion_settings"] = {"min_confidence": float(settings["min_confidence"]),
                                    "smooth_ms": float(settings["smooth_ms"])}
    except (KeyError, TypeError, ValueError, OverflowError) as exc:
        raise TrackingError(f"Niepoprawny model klasyfikacji: {exc}.") from exc
    return model


def load_model(path=DEFAULT_MODEL):
    path = Path(path).expanduser().resolve()
    if not path.is_file():
        raise TrackingError(f"Brak wytrenowanego modelu: {path}. Dodaj przyklady (opcja 10), potem wykonaj trening (11).")
    if path.stat().st_size > 20 * 1024 * 1024:
        raise TrackingError("Plik modelu jest zbyt duzy lub nie jest modelem Wheelczura.")
    try:
        model = json.loads(path.read_text(encoding="utf-8"))
    except (ValueError, UnicodeError) as exc:
        raise TrackingError("Nie mozna odczytac modelu. Wymagany jest zapisany model klasyfikacji JSON.") from exc
    return validate_model(model)


def predict_csv(path, model, fps=None, decision_confidence=None):
    model = validate_model(model)
    threshold = model["decision_confidence"] if decision_confidence is None else decision_confidence
    if not math.isfinite(threshold) or not 0.5 <= threshold <= 1:
        raise TrackingError("Prog decyzji musi byc pomiedzy 0.5 i 1.")
    try:
        features, report = features_from_csv(path, model["limb"], model["motion_settings"], fps)
    except FeatureError as exc:
        return {"status": "insufficient_data", "label": None, "reason": str(exc)}
    score = float(model_scores(model["parameters"], features))
    confidence = max(score, 1 - score)
    if confidence < threshold:
        return {"status": "uncertain", "label": None, "model_score_abnormal": score,
                "reason": "Model nie rozroznia dostatecznie pewnie obu klas dla tego nagrania."}
    return {"status": "ok", "label": LABELS[int(score >= 0.5)], "model_score_abnormal": score,
            "coverage": {name: report["limbs"][name]["coverage"] for name in selected_limbs(model["limb"])}}


def predict_source(source, model_path=DEFAULT_MODEL, cache_dir=None, tracking_options=None,
                   fps=None, decision_confidence=None, progress=None):
    from .dataset import prepare_tracking_csv
    model = load_model(model_path)
    cache_dir = cache_dir or Path(model_path).expanduser().resolve().parent / ".gait-cache"
    csv_path = prepare_tracking_csv(source, cache_dir, model["limb"], tracking_options, progress)
    return predict_csv(csv_path, model, fps=fps, decision_confidence=decision_confidence)


def print_prediction(result):
    if result["status"] == "ok":
        print("RUCH PRAWIDŁOWY" if result["label"] == LABELS[0] else "RUCH NIEPRAWIDŁOWY")
    else:
        print("BRAK OCENY: " + result["reason"])


def print_training_summary(model, path):
    info = model["training"]
    print(f"Trening zakonczony: {info['samples']} nagran, {info['dogs']} psow.")
    print(f"Model zapisany: {Path(path).resolve()}")
    validation = info["validation"]
    if validation["status"] == "ok":
        accuracy = validation["metrics"]["balanced_accuracy"]
        print(f"Walidacja na innych psach: trafnosc zrownowazona {accuracy:.1%}.")
    for note in info["notes"]:
        print("Uwaga: " + note)
    print("Klasy wynikaja z Twoich etykiet. Ocena modelu nie jest diagnoza weterynaryjna.")
