"""A two-state Gaussian HMM fitted to each recording, using NumPy only.

The observation is the projected elbow/knee angle. States describe relatively
more flexed/extended postures, not ground contact or a medical condition.
Independent sequences must be supplied at gaps; no transition crosses a gap.
"""

import numpy as np


class GaussianPhaseModel:
    labels = ("more_flexed", "more_extended")

    def __init__(self, max_iter=40, tolerance=1e-4):
        self.max_iter = max_iter
        self.tolerance = tolerance

    def _expectation(self, values):
        log_emission = -0.5 * (
            np.log(2 * np.pi * self.variances)[None, :]
            + (values[:, None] - self.means[None, :]) ** 2 / self.variances
        )
        offset = log_emission.max(axis=1)
        emission = np.exp(log_emission - offset[:, None])
        alpha = np.empty_like(emission)
        scale = np.empty(len(values))
        alpha[0] = self.start * emission[0]
        scale[0] = max(alpha[0].sum(), 1e-300)
        alpha[0] /= scale[0]
        for t in range(1, len(values)):
            alpha[t] = (alpha[t - 1] @ self.transition) * emission[t]
            scale[t] = max(alpha[t].sum(), 1e-300)
            alpha[t] /= scale[t]
        beta = np.ones_like(emission)
        for t in range(len(values) - 2, -1, -1):
            beta[t] = self.transition @ (emission[t + 1] * beta[t + 1]) / scale[t + 1]
        posterior = alpha * beta
        posterior /= posterior.sum(axis=1, keepdims=True)
        transitions = (
            alpha[:-1, :, None] * self.transition[None, :, :]
            * (emission[1:] * beta[1:])[:, None, :] / scale[1:, None, None]
        ).sum(axis=0)
        likelihood = float((np.log(scale) + offset).sum())
        return posterior, transitions, likelihood, log_emission

    def fit(self, sequences):
        sequences = [np.asarray(s, dtype=float) for s in sequences if len(s)]
        if not sequences or any(s.ndim != 1 or not np.isfinite(s).all() for s in sequences):
            raise ValueError("HMM requires nonempty finite one-dimensional sequences.")
        values = np.concatenate(sequences)
        self.means = np.percentile(values, [25, 75])
        self.variances = np.full(2, max(float(values.var()) / 2, 1.0))
        self.start = np.full(2, 0.5)
        self.transition = np.array([[0.95, 0.05], [0.05, 0.95]])
        self.history = []
        self.converged = False
        for _ in range(self.max_iter):
            weights = np.zeros(2)
            sums = np.zeros(2)
            squares = np.zeros(2)
            starts = np.full(2, 0.1)
            # A small persistence prior discourages one-frame state flicker.
            counts = np.array([[2.0, 0.1], [0.1, 2.0]])
            likelihood = 0.0
            for sequence in sequences:
                posterior, transitions, score, _ = self._expectation(sequence)
                weights += posterior.sum(axis=0)
                sums += posterior.T @ sequence
                squares += posterior.T @ (sequence ** 2)
                starts += posterior[0]
                counts += transitions
                likelihood += score
            self.history.append(likelihood)
            if len(self.history) > 1 and abs(likelihood - self.history[-2]) <= (
                self.tolerance * (1 + abs(self.history[-2]))
            ):
                self.converged = True
                break
            self.means = sums / np.maximum(weights, 1e-12)
            self.variances = np.maximum(squares / np.maximum(weights, 1e-12) - self.means ** 2, 1.0)
            self.start = starts / starts.sum()
            self.transition = counts / counts.sum(axis=1, keepdims=True)
        order = np.argsort(self.means)
        self.means, self.variances = self.means[order], self.variances[order]
        self.start = self.start[order]
        self.transition = self.transition[np.ix_(order, order)]
        self.log_likelihood = sum(self._expectation(s)[2] for s in sequences)
        return self

    def predict(self, values):
        values = np.asarray(values, dtype=float)
        posterior, _, _, emission = self._expectation(values)
        delta = np.log(self.start) + emission[0]
        back = np.zeros((len(values), 2), dtype=int)
        for t in range(1, len(values)):
            scores = delta[:, None] + np.log(self.transition)
            back[t] = scores.argmax(axis=0)
            delta = scores.max(axis=0) + emission[t]
        states = np.empty(len(values), dtype=int)
        states[-1] = delta.argmax()
        for t in range(len(values) - 2, -1, -1):
            states[t] = back[t + 1, states[t + 1]]
        return states, posterior[np.arange(len(values)), states]

    def to_dict(self):
        return {
            "type": "two_state_gaussian_hmm", "training": "unsupervised_per_recording_per_limb",
            "feature": "smoothed_projected_joint_angle_deg", "state_labels": list(self.labels),
            "means_deg": self.means.tolist(), "variances_deg2": self.variances.tolist(),
            "transition_matrix": self.transition.tolist(), "start_probabilities": self.start.tolist(),
            "iterations": len(self.history), "converged": self.converged,
            "log_likelihood": self.log_likelihood,
        }
