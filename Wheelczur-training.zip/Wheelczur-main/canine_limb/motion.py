"""Motion analysis of existing Wheelczur CSV exports; no video models needed."""

from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
import csv
import json
import math
import os
import tempfile

import numpy as np

from . import __version__
from .runtime import TrackingError
from .schema import LIMBS
from .temporal import GaussianPhaseModel


MOTION_FIELDS = (
    "frame", "time_s", "limb", "data_status", "segment", "angle_deg",
    "angular_velocity_deg_s", "paw_x_px", "paw_y_px", "relative_paw_x_limb_lengths",
    "relative_paw_y_limb_lengths", "relative_paw_speed_limb_lengths_s",
    "phase", "phase_probability",
)


@dataclass
class MotionConfig:
    min_confidence: float = 0.0
    smooth_ms: float = 100.0
    fps: float | None = None

    def validate(self):
        if not math.isfinite(self.min_confidence) or self.min_confidence < 0:
            raise TrackingError("Motion confidence must be finite and nonnegative.")
        if not math.isfinite(self.smooth_ms) or not 0 <= self.smooth_ms <= 1000:
            raise TrackingError("Motion smoothing must be between 0 and 1000 ms.")
        if self.fps is not None and (not math.isfinite(self.fps) or self.fps <= 0):
            raise TrackingError("Motion FPS must be finite and greater than zero.")


def _finite(value):
    return float(value) if value not in (None, "") else float("nan")


def _load_csv(path, config):
    records, times, found = {}, {}, set()
    required = {"frame", "time_s", "limb", "joint", "x_px", "y_px", "score", "status"}
    with Path(path).open(encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        if not required.issubset(reader.fieldnames or ()):
            raise TrackingError("Expected a Wheelczur tracking CSV; missing columns: "
                                + ", ".join(sorted(required - set(reader.fieldnames or ()))))
        for line, row in enumerate(reader, 2):
            try:
                frame, stamp = int(row["frame"]), float(row["time_s"])
                limb, joint = row["limb"], row["joint"]
                if not 0 <= frame <= np.iinfo(np.int64).max or not math.isfinite(stamp) or stamp < 0:
                    raise ValueError("frame/time must be finite and nonnegative")
                if limb not in LIMBS or joint not in LIMBS[limb][1]:
                    raise ValueError("unknown limb or joint")
                key = frame, limb, joint
                if key in records:
                    raise ValueError("duplicate frame/limb/joint")
                if frame in times and not math.isclose(times[frame], stamp, abs_tol=1e-7, rel_tol=0):
                    raise ValueError("inconsistent time within a frame")
                times[frame] = stamp
                found.add(limb)
                point = (_finite(row["x_px"]), _finite(row["y_px"]))
                score = _finite(row["score"])
                valid = (row["status"] == "detected" and math.isfinite(score)
                         and score >= config.min_confidence and all(map(math.isfinite, point)))
                records[key] = point if valid else (float("nan"),) * 2
            except (ValueError, TypeError, KeyError) as exc:
                raise TrackingError(f"Invalid tracking CSV at line {line}: {exc}.") from exc
    if not records:
        raise TrackingError("The tracking CSV has no observations.")
    frames = np.array(sorted(times), dtype=np.int64)
    stamps = np.array([times[int(f)] for f in frames])
    if config.fps is None and len(frames) > 1 and np.any(np.diff(stamps) <= 0):
        raise TrackingError("CSV times must increase with frame numbers.")
    if config.fps is not None:
        stamps = frames / config.fps
        fps = config.fps
    elif len(frames) > 1:
        dt = np.diff(stamps) / np.diff(frames)
        interval = float(np.median(dt))
        if not np.allclose(dt, interval, rtol=1e-4, atol=2e-9):
            raise TrackingError("CSV does not have a constant frame rate. Supply --fps if appropriate.")
        # Endpoints average nanosecond rounding in exported timestamps. Snap
        # near-integer rates so e.g. 60.00000002 does not require 61 frames.
        fps = float((frames[-1] - frames[0]) / (stamps[-1] - stamps[0]))
        if math.isclose(fps, round(fps), rel_tol=1e-7, abs_tol=1e-9):
            fps = float(round(fps))
    else:
        # A single frame has angles but no measurable speed or temporal model.
        fps = None
    points = {
        limb: np.array([[records.get((int(f), limb, joint), (float("nan"),) * 2)
                         for joint in LIMBS[limb][1]] for f in frames])
        for limb in LIMBS if limb in found
    }
    return frames, stamps, fps, points


def _segments(valid, frames):
    """Indices of contiguous, fully observed frames; never bridge a missing frame."""
    indices = np.flatnonzero(valid)
    if not len(indices):
        return []
    cuts = np.flatnonzero((np.diff(indices) != 1) | (np.diff(frames[indices]) != 1)) + 1
    return list(np.split(indices, cuts))


def _smooth(points, segments, window):
    result = points.copy()
    if window <= 1:
        return result
    for segment in segments:
        # A centered moving mean with a truncated window at each segment edge.
        # Missing observations are never interpolated or used as filter support.
        half = min(window // 2, (len(segment) - 1) // 2)
        if half == 0:
            continue
        source = points[segment]
        sums = np.concatenate((np.zeros_like(source[:1]), np.cumsum(source, axis=0)))
        start = np.maximum(0, np.arange(len(segment)) - half)
        end = np.minimum(len(segment), np.arange(len(segment)) + half + 1)
        result[segment] = (sums[end] - sums[start]) / (end - start)[:, None, None]
    return result


def _derivative(values, stamps, segments):
    derivative = np.full_like(values, np.nan, dtype=float)
    for segment in segments:
        if len(segment) >= 2:
            derivative[segment] = np.gradient(values[segment], stamps[segment], axis=0)
    return derivative


def _stats(values):
    values = np.asarray(values)
    values = values[np.isfinite(values)]
    if not len(values):
        return None
    low, high = np.percentile(values, [5, 95])
    return {"mean": float(values.mean()), "min": float(values.min()), "max": float(values.max()),
            "p05": float(low), "p95": float(high), "range_p05_p95": float(high - low)}


def _periodicity(relative_x, segments, fps):
    """A conservative repeat-period estimate from the longest observed segment."""
    unavailable = {"status": "insufficient_contiguous_data", "period_s": None, "frequency_hz": None}
    if fps is None or not segments:
        return unavailable
    segment = max(segments, key=len)
    n = len(segment)
    low, high = max(2, math.ceil(0.2 * fps)), min(math.floor(3 * fps), (n - 1) // 3)
    if high < low + 1:
        return unavailable
    values = relative_x[segment].copy()
    index = np.arange(n, dtype=float)
    slope, intercept = np.polyfit(index, values, 1)
    values -= slope * index + intercept
    if float(np.std(values)) < 0.005:
        return {**unavailable, "status": "low_paw_excursion"}
    fft_size = 1 << (2 * n - 1).bit_length()
    spectrum = np.fft.rfft(values, n=fft_size)
    numerator = np.fft.irfft(spectrum * spectrum.conj(), n=fft_size)[:high + 2]
    energy = np.concatenate(([0.0], np.cumsum(values ** 2)))
    lags = np.arange(high + 2)
    denominator = np.sqrt(energy[n - lags] * (energy[n] - energy[lags]))
    correlation = numerator / np.maximum(denominator, 1e-12)
    peaks = [i for i in range(low, high + 1) if correlation[i] >= 0.55
             and correlation[i] > correlation[i - 1] and correlation[i] >= correlation[i + 1]]
    if not peaks:
        return {**unavailable, "status": "no_reliable_periodicity"}
    best = max(float(correlation[i]) for i in peaks)
    lag = next(i for i in peaks if correlation[i] >= 0.9 * best)
    return {"status": "ok", "period_s": lag / fps, "frequency_hz": fps / lag,
            "autocorrelation": float(np.clip(correlation[lag], -1, 1)),
            "complete_periods_in_segment": (n - 1) // lag,
            "segment_start_index": int(segment[0]), "segment_end_index": int(segment[-1]),
            "method": "first strong local autocorrelation peak; at least three periods"}


def _phase_model(angles, segments, fps):
    states = np.full(len(angles), -1, dtype=int)
    probability = np.full(len(angles), np.nan)
    minimum = max(6, round(0.2 * fps)) if fps else 6
    sequences = [s for s in segments if len(s) >= minimum]
    if fps is None or sum(map(len, sequences)) < max(12, math.ceil(fps)):
        return states, probability, {"status": "insufficient_data"}
    observations = np.concatenate([angles[s] for s in sequences])
    if np.ptp(np.percentile(observations, [5, 95])) < 5:
        return states, probability, {"status": "low_angle_variation"}
    model = GaussianPhaseModel().fit([angles[s] for s in sequences])
    if model.means[1] - model.means[0] < 5:
        return states, probability, {"status": "states_not_separated", "parameters": model.to_dict()}
    for sequence in sequences:
        states[sequence], probability[sequence] = model.predict(angles[sequence])
    total = int((states >= 0).sum())
    fractions = {label: float((states == i).sum() / total) for i, label in enumerate(model.labels)}
    return states, probability, {"status": "ok", "model_frames": total,
                                "state_fractions": fractions, "parameters": model.to_dict()}


def _limb_motion(points, frames, stamps, fps, config, total_frames):
    valid = np.isfinite(points).all(axis=(1, 2))
    lengths = np.linalg.norm(np.diff(points, axis=1), axis=2)
    valid &= (lengths > 1e-6).all(axis=1)
    segments = _segments(valid, frames)
    window = max(1, round(config.smooth_ms * fps / 1000)) if fps else 1
    if window % 2 == 0:
        window += 1
    smooth = _smooth(points, segments, window)
    root, middle, paw = smooth[:, 0], smooth[:, 1], smooth[:, 2]
    a, b = root - middle, paw - middle
    denominator = np.linalg.norm(a, axis=1) * np.linalg.norm(b, axis=1)
    # Smoothing can collapse a segment too: re-check before forming any angle.
    valid &= np.isfinite(denominator) & (denominator > 1e-12)
    segments = _segments(valid, frames)
    angle = np.full(len(frames), np.nan)
    angle[valid] = np.degrees(np.arccos(np.clip(
        np.einsum("ij,ij->i", a[valid], b[valid]) / denominator[valid], -1, 1)))
    reference = float(np.median(lengths[valid].sum(axis=1))) if valid.any() else None
    relative = np.full((len(frames), 2), np.nan)
    if reference:
        relative[valid] = (paw[valid] - root[valid]) / reference
    velocity = _derivative(relative, stamps, segments)
    speed = np.linalg.norm(velocity, axis=1)
    angular_velocity = _derivative(angle, stamps, segments)
    states, probability, temporal = _phase_model(angle, segments, fps)
    periodicity = _periodicity(relative[:, 0], segments, fps)
    if periodicity["status"] == "ok":
        periodicity["segment_start_frame"] = int(frames[periodicity.pop("segment_start_index")])
        periodicity["segment_end_frame"] = int(frames[periodicity.pop("segment_end_index")])
    count = int(valid.sum())
    coverage = count / total_frames
    quality = ("insufficient_data" if fps is None or count < max(12, math.ceil(fps)) else
               "low_coverage" if coverage < 0.6 else "usable")
    pairs = sum(max(0, len(s) - 1) for s in segments)
    path = sum(float(np.linalg.norm(np.diff(relative[s], axis=0), axis=1).sum()) for s in segments)
    summary = {
        "quality": quality, "complete_joint_frames": count, "coverage": coverage,
        "missing_or_rejected_frames": total_frames - count,
        "contiguous_segments": len(segments), "smoothing_window_frames": window,
        "reference_limb_length_px": reference,
        "joint_angle_deg": _stats(angle), "angular_speed_deg_s": _stats(np.abs(angular_velocity)),
        "relative_paw_x_limb_lengths": _stats(relative[:, 0]),
        "relative_paw_y_limb_lengths": _stats(relative[:, 1]),
        "relative_paw_speed_limb_lengths_s": _stats(speed),
        "relative_paw_path_limb_lengths": path if pairs else None,
        "periodicity": periodicity, "temporal_model": temporal,
    }
    segment_numbers = np.full(len(frames), -1, dtype=int)
    for number, segment in enumerate(segments):
        segment_numbers[segment] = number
    return summary, {"valid": valid, "angle": angle, "angular_velocity": angular_velocity,
                     "paw": paw, "relative": relative, "speed": speed, "states": states,
                     "probability": probability, "segments": segment_numbers}


def _difference(left, right):
    denominator = abs(left) + abs(right)
    return 200 * abs(left - right) / denominator if denominator > 1e-6 else None


def _symmetry(series, total_frames, fps):
    comparisons = {}
    for name, left, right in (("fore", "left-fore", "right-fore"), ("hind", "left-hind", "right-hind")):
        if left not in series or right not in series:
            comparisons[name] = {"status": "both_limbs_required"}
            continue
        l, r = series[left], series[right]
        shared = l["valid"] & r["valid"]
        count = int(shared.sum())
        if fps is None or count < max(12, math.ceil(fps)) or count / total_frames < 0.5:
            comparisons[name] = {"status": "insufficient_shared_data", "shared_frames": count}
            continue
        l_rom, r_rom = (_stats(x["angle"][shared])["range_p05_p95"] for x in (l, r))
        l_exc, r_exc = (_stats(x["relative"][shared, 0])["range_p05_p95"] for x in (l, r))
        comparisons[name] = {
            "status": "ok", "shared_frames": count, "shared_coverage": count / total_frames,
            "left_angle_range_deg": l_rom, "right_angle_range_deg": r_rom,
            "angle_range_relative_difference_pct": _difference(l_rom, r_rom),
            "left_paw_x_excursion_limb_lengths": l_exc, "right_paw_x_excursion_limb_lengths": r_exc,
            "paw_x_excursion_relative_difference_pct": _difference(l_exc, r_exc),
        }
    return comparisons


def analyze_tracking(csv_path, config=None):
    """Return a JSON-safe report and per-frame kinematics from a tracking CSV."""
    config = config or MotionConfig()
    config.validate()
    frames, stamps, fps, points = _load_csv(csv_path, config)
    total = int(frames[-1]) - int(frames[0]) + 1
    limbs, series = {}, {}
    for limb, coordinates in points.items():
        limbs[limb], series[limb] = _limb_motion(coordinates, frames, stamps, fps, config, total)
    warnings = [
        "Measurements are 2D projections, not anatomical 3D angles or ground-contact labels.",
        "HMM states are relative postures learned from this recording, not a disease classifier.",
        "Paw coordinates are relative to the shoulder/hip and normalized by median visible limb length.",
        "Camera rotation, perspective, occlusion, turns, tracking identity errors and pose jitter can affect results.",
        "Periodicity describes repeated paw motion; it does not identify walk/trot or prove a footfall.",
    ]
    for limb, summary in limbs.items():
        if summary["quality"] != "usable":
            warnings.append(f"{limb}: {summary['quality']}; inspect coverage before interpreting metrics.")
    report = {
        "program_version": __version__, "analysis_version": 1,
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "tracking_csv": str(Path(csv_path).resolve()), "fps": fps,
        "time_basis": "frame / supplied FPS" if config.fps else "validated constant-rate CSV timestamps",
        "first_frame": int(frames[0]), "last_frame": int(frames[-1]),
        "frames_in_span": total, "frames_present_in_csv": len(frames),
        "duration_between_observations_s": float(stamps[-1] - stamps[0]),
        "settings": {"min_confidence": config.min_confidence, "smooth_ms": config.smooth_ms,
                     "fps_override": config.fps, "gap_policy": "no interpolation; reset at every gap"},
        "limbs": limbs, "symmetry": _symmetry(series, total, fps), "limitations": warnings,
    }

    def rows():
        for i, frame in enumerate(frames):
            for limb, data in series.items():
                valid, state = bool(data["valid"][i]), int(data["states"][i])
                values = (
                    int(frame), float(stamps[i]), limb, "valid" if valid else "missing_or_rejected",
                    int(data["segments"][i]) if valid else None,
                    data["angle"][i], data["angular_velocity"][i],
                    *(data["paw"][i] if valid else (np.nan, np.nan)),
                    *data["relative"][i], data["speed"][i],
                    GaussianPhaseModel.labels[state] if state >= 0 else "unknown", data["probability"][i],
                )
                yield {key: (None if isinstance(value, (float, np.floating)) and not math.isfinite(value)
                             else value) for key, value in zip(MOTION_FIELDS, values)}
    return report, rows()


def motion_paths(csv_path, output_dir=None):
    csv_path = Path(csv_path)
    root = Path(output_dir).expanduser() if output_dir else csv_path.parent
    return {"motion_report": root / f"{csv_path.stem}_motion.json",
            "motion_csv": root / f"{csv_path.stem}_motion.csv"}


def write_analysis(csv_path, paths, config=None, source_csv=None):
    """Write to caller-owned staging paths; used by both processing workflows."""
    report, rows = analyze_tracking(csv_path, config)
    report["tracking_csv"] = str(Path(source_csv or csv_path).resolve())
    with Path(paths["motion_csv"]).open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=MOTION_FIELDS)
        writer.writeheader()
        writer.writerows(rows)
    Path(paths["motion_report"]).write_text(
        json.dumps(report, indent=2, ensure_ascii=False, allow_nan=False) + "\n", encoding="utf-8")
    return report


def run_motion(csv_path, output_dir=None, config=None, overwrite=False):
    csv_path = Path(csv_path).expanduser().resolve()
    if not csv_path.is_file():
        raise TrackingError(f"Tracking CSV does not exist: {csv_path}")
    paths = {key: path.resolve() for key, path in motion_paths(csv_path, output_dir).items()}
    for path in paths.values():
        if path == csv_path or (path.exists() and (not overwrite or not path.is_file())):
            raise TrackingError(f"Output already exists: {path}. Choose another --output-dir or use --overwrite.")
    root = paths["motion_csv"].parent
    root.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix=".canine-motion-", dir=root) as temporary:
        staged = {key: Path(temporary) / path.name for key, path in paths.items()}
        report = write_analysis(csv_path, staged, config)
        for path in paths.values():
            if path.exists() and (not overwrite or not path.is_file()):
                raise TrackingError(f"Output already exists: {path}. Use --overwrite to replace it.")
        for key, path in paths.items():
            os.replace(staged[key], path)
    return {"report": report, "outputs": {key: str(path) for key, path in paths.items()}}


def print_motion_summary(report):
    print("Motion analysis (2D; relative HMM postures):")
    for limb, summary in report["limbs"].items():
        angle = summary["joint_angle_deg"]
        rom = f"{angle['range_p05_p95']:.1f} deg" if angle else "unavailable"
        periodicity = summary["periodicity"]
        period = (f"{periodicity['period_s']:.3f} s ({periodicity['frequency_hz']:.2f} Hz)"
                  if periodicity["status"] == "ok" else periodicity["status"])
        print(f"  {limb}: coverage {summary['coverage']:.0%}; angle range {rom}; repeat period {period}; "
              f"HMM {summary['temporal_model']['status']}; quality {summary['quality']}")
    for pair, comparison in report["symmetry"].items():
        if comparison["status"] == "ok":
            value = comparison["angle_range_relative_difference_pct"]
            label = f"{value:.1f}%" if value is not None else "unavailable (near-zero range)"
            print(f"  {pair}: left/right angle-range difference {label} (shared observations)")
