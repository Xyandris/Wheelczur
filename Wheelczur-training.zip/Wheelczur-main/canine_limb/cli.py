"""Interactive prompts and equivalent non-interactive CLI arguments."""

from pathlib import Path
import argparse
import json
import math
import sys
import time

from . import __version__
from .runtime import TrackingError, parse_device
from .schema import LIMBS


def device_argument(value):
    try:
        parse_device(value)
    except ValueError as exc:
        raise argparse.ArgumentTypeError(str(exc)) from exc
    return value


def finite_number(value):
    try:
        result = float(value)
    except ValueError as exc:
        raise argparse.ArgumentTypeError("Expected a finite number.") from exc
    if not math.isfinite(result):
        raise argparse.ArgumentTypeError("Expected a finite number.")
    return result


def parser():
    p = argparse.ArgumentParser(
        description="Track canine limbs and analyze motion, or analyze an existing tracking CSV.",
        epilog='Examples: python track_limb.py "walk.mp4" --limb all; python track_limb.py --analyze walk_all.csv',
    )
    p.add_argument("video", nargs="?", help="Input video path; prompts when omitted.")
    p.add_argument("--limb", type=lambda s: s.replace("_", "-"), choices=(*LIMBS, "all"),
                   help="Animal's left/right side; prompts when omitted.")
    p.add_argument("--device", type=device_argument, default="cpu", help="cpu (default), or cuda:N for an NVIDIA GPU.")
    p.add_argument("--output-dir", type=Path,
                   help="Default: <video_stem>_tracking/ beside video; with --analyze, beside CSV.")
    p.add_argument("--confidence", type=finite_number, default=0.3, help="Minimum raw SimCC score (default 0.3).")
    p.add_argument("--detector-confidence", type=finite_number, default=0.3, help="Minimum dog detection probability (default 0.3).")
    p.add_argument("--dog-index", type=int, default=0, help="Initial target: 0=largest dog, 1=next largest, etc.")
    p.add_argument("--bbox", type=finite_number, nargs=4, metavar=("X", "Y", "WIDTH", "HEIGHT"),
                   help="Fixed whole-dog crop in pixels; skips automatic detection. Include the whole dog.")
    p.add_argument("--fps", type=finite_number, help="Override FPS when metadata is wrong/missing.")
    p.add_argument("--video-format", choices=("mp4", "avi"), default="mp4", help="mp4=mp4v (default), avi=MJPEG.")
    p.add_argument("--models-dir", type=Path, help="Directory containing the unchanged supplied ONNX models.")
    p.add_argument("--overwrite", action="store_true", help="Replace existing outputs after processing succeeds.")
    p.add_argument("--analyze", type=Path, metavar="TRACKING_CSV",
                   help="Analyze a previously exported CSV without loading video/ONNX models.")
    p.add_argument("--no-motion", action="store_true", help="Only track points; skip automatic motion analysis.")
    p.add_argument("--motion-confidence", type=finite_number, default=0.0,
                   help="Additional raw-score filter for motion; original CSV statuses always apply (default 0).")
    p.add_argument("--motion-smooth-ms", type=finite_number, default=100.0,
                   help="Motion smoothing window in milliseconds, 0 disables it (default 100).")
    p.add_argument("--check-cuda", action="store_true", help="Run both models and verify actual CUDA compute; requires --device cuda:N.")
    p.add_argument("--add-sample", type=Path, metavar="VIDEO_OR_CSV", help="Add a labelled recording to the training dataset.")
    p.add_argument("--train", action="store_true", help="Train and save a normal/abnormal classifier from the labelled dataset.")
    p.add_argument("--predict", type=Path, metavar="VIDEO_OR_CSV", help="Print whether motion is normal or abnormal using a trained model.")
    p.add_argument("--dataset", type=Path, help="Training folder (default: training_data in the project).")
    p.add_argument("--gait-model", type=Path, help="Saved classifier (default: gait_model.json in the project).")
    p.add_argument("--label", choices=("prawidlowy", "nieprawidlowy"), help="Label for --add-sample.")
    p.add_argument("--dog-id", help="Dog ID for --add-sample; use the same ID for every recording of the same dog.")
    p.add_argument("--decision-confidence", type=finite_number, help="Minimum winning model score for --predict, 0.5-1 (default 0.6).")
    p.add_argument("--version", action="version", version=__version__)
    return p


def prompt_limb():
    options = (*LIMBS, "all")
    print("Choose a limb (left/right refer to the dog's own sides):")
    for i, name in enumerate(options, 1):
        print(f"  {i}. {name}")
    while True:
        answer = input("Limb number or name: ").strip().lower().replace("_", "-")
        if answer in options:
            return answer
        if answer in {str(i) for i in range(1, len(options) + 1)}:
            return options[int(answer) - 1]
        print("Choose 1-5 or enter a listed limb name.")


def input_path(value):
    value = value.strip()
    if len(value) >= 2 and value[0] == value[-1] and value[0] in "\"'":
        value = value[1:-1]
    if not value:
        raise TrackingError("Enter a video path.")
    return Path(value).expanduser()


def _tracking_options(args):
    return {"device": args.device, "confidence": args.confidence,
            "detector_confidence": args.detector_confidence, "dog_index": args.dog_index,
            "bbox": tuple(args.bbox) if args.bbox else None, "fps": args.fps, "models_dir": args.models_dir}


def _learning_action(args):
    from .dataset import add_sample
    from .gait import (DEFAULT_DATASET, DEFAULT_MODEL, predict_source, print_prediction,
                       print_training_summary, train_classifier)
    dataset, model_path = args.dataset or DEFAULT_DATASET, args.gait_model or DEFAULT_MODEL
    settings = {"min_confidence": args.motion_confidence, "smooth_ms": args.motion_smooth_ms}
    progress = lambda message: print(message, flush=True)
    if args.add_sample is not None:
        if args.label is None or args.dog_id is None:
            raise TrackingError("--add-sample wymaga --label prawidlowy/nieprawidlowy oraz --dog-id ID_PSA.")
        result = add_sample(input_path(str(args.add_sample)), args.label, args.dog_id, dataset,
                            args.limb or "all", settings, _tracking_options(args), progress)
        print(("Przyklad juz jest w zbiorze: " if result["status"] == "already_added" else "Dodano przyklad: ")
              + result["path"])
    elif args.train:
        model = train_classifier(dataset, model_path, args.limb or "all", settings,
                                 _tracking_options(args), progress)
        print_training_summary(model, model_path)
    else:
        result = predict_source(input_path(str(args.predict)), model_path, tracking_options=_tracking_options(args),
                                fps=args.fps, decision_confidence=args.decision_confidence, progress=progress)
        print_prediction(result)
    return 0


def _print_saved_prediction(csv_path, args, fps=None):
    from .gait import DEFAULT_MODEL, load_model, predict_csv, print_prediction
    path = args.gait_model or DEFAULT_MODEL
    if args.gait_model is not None or Path(path).is_file():
        print_prediction(predict_csv(csv_path, load_model(path), fps, args.decision_confidence))


def main(argv=None):
    p = parser()
    args = p.parse_args(argv)
    try:
        learning = (args.add_sample is not None, args.train, args.predict is not None)
        if any(learning):
            if sum(learning) != 1 or args.video is not None or args.analyze is not None or args.check_cuda or args.no_motion:
                raise TrackingError("Choose exactly one of --add-sample, --train or --predict; do not combine it with other actions.")
            return _learning_action(args)
        if args.analyze is not None:
            if args.video is not None or args.check_cuda or args.no_motion:
                raise TrackingError("--analyze cannot be combined with VIDEO, --check-cuda or --no-motion.")
            from .motion import MotionConfig, print_motion_summary, run_motion
            result = run_motion(input_path(str(args.analyze)), args.output_dir,
                                MotionConfig(args.motion_confidence, args.motion_smooth_ms, args.fps),
                                args.overwrite)
            print_motion_summary(result["report"])
            for label, path in result["outputs"].items():
                print(f"{label}: {path}")
            _print_saved_prediction(input_path(str(args.analyze)), args, args.fps)
            return 0
        if args.check_cuda:
            if parse_device(args.device)[0] != "cuda":
                raise TrackingError("--check-cuda requires --device cuda:N.")
            from .models import DogDetector, PoseModel
            pose = PoseModel(args.device, args.models_dir)
            detector = DogDetector(args.device, args.models_dir)
            print(json.dumps({"pose": pose.info, "detector": detector.info}, indent=2))
            return 0
        video = input_path(args.video if args.video is not None else input("Path to video: "))
        limb = args.limb or prompt_limb()
        from .pipeline import Config, run_video
        last_update = 0.0

        def progress(done, total):
            nonlocal last_update
            now = time.monotonic()
            if now - last_update >= 1 or done == total:
                count = f"{done}/{total}" if total else str(done)
                print(f"\rProcessed {count} frames", end="", file=sys.stderr, flush=True)
                last_update = now

        print(f"Using {args.device}; loading RTMPose and {'fixed crop' if args.bbox else 'dog detector'}...", file=sys.stderr)
        result = run_video(Config(
            video=video, limb=limb, output_dir=args.output_dir, device=args.device,
            confidence=args.confidence, detector_confidence=args.detector_confidence,
            dog_index=args.dog_index, bbox=tuple(args.bbox) if args.bbox else None,
            fps=args.fps, video_format=args.video_format, models_dir=args.models_dir,
            overwrite=args.overwrite,
            motion=not args.no_motion, motion_confidence=args.motion_confidence,
            motion_smooth_ms=args.motion_smooth_ms,
        ), progress=progress)
        print(file=sys.stderr)
        print(f"Finished: {result['frames']} frames; {result['joint_status_counts'].get('detected', 0)} valid joint observations.")
        for label, path in result["outputs"].items():
            print(f"{label}: {path}")
        if "motion_report" in result["outputs"]:
            from .motion import print_motion_summary
            print_motion_summary(json.loads(Path(result["outputs"]["motion_report"]).read_text(encoding="utf-8")))
            _print_saved_prediction(result["outputs"]["csv"], args, result["fps"])
        if not result["joint_status_counts"].get("detected", 0):
            print("No valid joints were detected. Check the footage/crop and the confidence threshold.", file=sys.stderr)
        return 0
    except EOFError:
        print("Error: input ended. Supply VIDEO and --limb for non-interactive use.", file=sys.stderr)
        return 2
    except KeyboardInterrupt:
        print("\nInterrupted. Unfinished temporary outputs are discarded.", file=sys.stderr)
        return 130
    except (TrackingError, OSError, ValueError) as exc:
        print(f"\nError: {exc}", file=sys.stderr)
        return 1
    except ImportError as exc:
        print(f'Error: missing dependency ({exc}). Install with: python -m pip install ".[cpu]" '
              '(or ".[cuda]" for NVIDIA tracking).', file=sys.stderr)
        return 1
