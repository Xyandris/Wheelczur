"""Labelled recording storage and content-addressed video-to-keypoint caching."""

from pathlib import Path
import csv
import hashlib
import json
import math
import os
import re
import shutil
import tempfile
import time

from .runtime import TrackingError


VIDEO_SUFFIXES = {".mp4", ".avi", ".mov", ".mkv", ".m4v", ".webm", ".mpeg", ".mpg"}
LABELS = ("prawidlowy", "nieprawidlowy")


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _dog_id(value):
    if not isinstance(value, str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]{0,63}", value):
        raise TrackingError("Identyfikator psa: 1-64 znaki, litery ASCII, cyfry, _ lub -; bez spacji.")
    return value.casefold()


def _source(path):
    path = Path(path).expanduser().resolve()
    if not path.is_file():
        raise TrackingError(f"Nie znaleziono nagrania lub CSV: {path}")
    if path.suffix.lower() not in VIDEO_SUFFIXES | {".csv"}:
        raise TrackingError("Podaj film lub oryginalny CSV z punktami, nie raport JSON.")
    if path.name.lower().endswith("_motion.csv"):
        raise TrackingError("Podaj oryginalny CSV z punktami. Plik *_motion.csv jest raportem analizy.")
    return path


def _retime_csv(source, cache_dir, fps):
    if not math.isfinite(fps) or fps <= 0:
        raise TrackingError("FPS musi byc skonczone i wieksze od zera.")
    signature = {"source_sha256": sha256(source), "fps": fps}
    key = hashlib.sha256(json.dumps(signature, sort_keys=True).encode()).hexdigest()
    cache = Path(cache_dir).expanduser().resolve()
    cache.mkdir(parents=True, exist_ok=True)
    destination, meta_path = cache / f"retimed_{key}.csv", cache / f"retimed_{key}.json"
    if destination.is_file() and meta_path.is_file():
        try:
            if json.loads(meta_path.read_text(encoding="utf-8"))["csv_sha256"] == sha256(destination):
                return destination
        except (ValueError, KeyError, TypeError):
            pass
    with tempfile.TemporaryDirectory(prefix=".retime-gait-", dir=cache) as temporary:
        staged = Path(temporary) / "retimed.csv"
        with source.open(encoding="utf-8-sig", newline="") as input_file, staged.open("w", encoding="utf-8-sig", newline="") as output_file:
            reader = csv.DictReader(input_file)
            if not {"frame", "time_s"}.issubset(reader.fieldnames or []):
                raise TrackingError("Wymagany jest oryginalny CSV z kolumnami frame i time_s.")
            writer = csv.DictWriter(output_file, fieldnames=reader.fieldnames)
            writer.writeheader()
            for line, row in enumerate(reader, 2):
                try:
                    frame = int(row["frame"])
                    if frame < 0:
                        raise ValueError("ujemny numer klatki")
                    row["time_s"] = frame / fps
                    writer.writerow(row)
                except (ValueError, TypeError) as exc:
                    raise TrackingError(f"Niepoprawna klatka w CSV, wiersz {line}.") from exc
        metadata = Path(temporary) / "meta.json"
        metadata.write_text(json.dumps({**signature, "csv_sha256": sha256(staged)}), encoding="utf-8")
        os.replace(staged, destination)
        os.replace(metadata, meta_path)
    return destination


def prepare_tracking_csv(source, cache_dir, limb="all", tracking_options=None, progress=None):
    source = _source(source)
    if source.suffix.lower() == ".csv":
        fps = (tracking_options or {}).get("fps")
        return source if fps is None else _retime_csv(source, cache_dir, fps)
    # Imports are intentionally lazy: CSV workflows need neither OpenCV nor ONNX weights.
    from .models import MODEL_HASHES
    from .pipeline import Config, run_video
    options = dict(tracking_options or {})
    allowed = {"device", "confidence", "detector_confidence", "dog_index", "bbox", "fps", "models_dir"}
    if set(options) - allowed:
        raise TrackingError("Nieznane ustawienia sledzenia nagrania.")
    config = Config(video=source, limb=limb, motion=False, **options)
    signature = {"version": 1, "source_sha256": sha256(source), "limb": limb,
                 "models": MODEL_HASHES,
                 "settings": {name: str(getattr(config, name)) if name == "models_dir"
                              else getattr(config, name) for name in sorted(allowed)}}
    signature = json.loads(json.dumps(signature, sort_keys=True))
    key = hashlib.sha256(json.dumps(signature, sort_keys=True).encode()).hexdigest()
    cache = Path(cache_dir).expanduser().resolve()
    cache.mkdir(parents=True, exist_ok=True)
    csv_path, meta_path = cache / f"{key}.csv", cache / f"{key}.json"
    if csv_path.is_file() and meta_path.is_file():
        try:
            metadata = json.loads(meta_path.read_text(encoding="utf-8"))
            if metadata["signature"] == signature and metadata["csv_sha256"] == sha256(csv_path):
                return csv_path
        except (ValueError, KeyError, TypeError):
            pass
    with tempfile.TemporaryDirectory(prefix=".prepare-gait-", dir=cache) as temporary:
        config.output_dir = Path(temporary) / "tracking"
        last_update = 0.0

        def report_progress(done, total):
            nonlocal last_update
            now = time.monotonic()
            if progress and (now - last_update >= 1 or done == total):
                progress(f"Punkty: {done}/{total or '?'} klatek")
                last_update = now

        result = run_video(config, progress=report_progress)
        staged = Path(temporary) / "points.csv"
        shutil.copyfile(result["outputs"]["csv"], staged)
        metadata = {"signature": signature, "csv_sha256": sha256(staged)}
        staged_meta = Path(temporary) / "cache.json"
        staged_meta.write_text(json.dumps(metadata, indent=2) + "\n", encoding="utf-8")
        os.replace(staged, csv_path)
        os.replace(staged_meta, meta_path)
    return csv_path


def collect_samples(dataset, allow_empty=False):
    dataset = Path(dataset).expanduser().resolve()
    if not dataset.is_dir():
        raise TrackingError("Brak zbioru treningowego. Dodaj nagrania opcja 10 w launcherze.")
    samples = []
    for label in LABELS:
        directory = dataset / label
        if not directory.is_dir():
            continue
        for path in sorted(directory.rglob("*")):
            if not path.is_file() or path.suffix.lower() not in VIDEO_SUFFIXES | {".csv"}:
                continue
            if path.name.lower().endswith("_motion.csv") or "_tracking" in path.parent.name:
                continue
            relative = path.relative_to(directory)
            if len(relative.parts) != 2:
                raise TrackingError(f"Niepoprawny uklad zbioru: {path}. "
                                    f"Uzyj {label}/ID_PSA/nagranie.csv lub dodaj film opcja 10.")
            dog = _dog_id(relative.parts[0])
            samples.append({"path": _source(path), "label": label, "dog_id": dog})
    if not samples and not allow_empty:
        raise TrackingError("Zbior jest pusty. Dodaj filmy lub CSV oznaczone jako prawidlowy i nieprawidlowy (opcja 10).")
    return samples


def add_sample(source, label, dog_id, dataset, limb="all", settings=None, tracking_options=None, progress=None):
    from .gait import features_from_csv
    if label not in LABELS:
        raise TrackingError("Etykieta musi miec wartosc prawidlowy albo nieprawidlowy.")
    dog_id = _dog_id(dog_id)
    source = _source(source)
    dataset = Path(dataset).expanduser().resolve()
    csv_path = prepare_tracking_csv(source, dataset / ".cache", limb, tracking_options, progress)
    features_from_csv(csv_path, limb, settings)
    digest = sha256(csv_path)
    # Identical point exports cannot count as different dogs or opposing labels.
    if dataset.is_dir():
        for other in collect_samples(dataset, allow_empty=True):
            if other["path"].suffix.lower() == ".csv" and sha256(other["path"]) == digest:
                if other["label"] != label:
                    raise TrackingError("Ten sam CSV jest juz oznaczony przeciwna etykieta. Popraw oznaczenie w zbiorze.")
                return {"status": "already_added", "path": str(other["path"]), "label": label, "dog_id": other["dog_id"]}
    stem = re.sub(r"[^A-Za-z0-9_-]+", "_", source.stem)[:70] or "nagranie"
    directory = dataset / label / dog_id
    directory.mkdir(parents=True, exist_ok=True)
    destination = directory / f"{stem}_{digest[:16]}.csv"
    with tempfile.TemporaryDirectory(prefix=".gait-sample-", dir=directory) as temporary:
        staged = Path(temporary) / "sample.csv"
        shutil.copyfile(csv_path, staged)
        os.replace(staged, destination)
    return {"status": "added", "path": str(destination), "label": label, "dog_id": dog_id}
