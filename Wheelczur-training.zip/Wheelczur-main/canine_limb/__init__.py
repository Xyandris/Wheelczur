"""Minimal canine limb tracking CLI."""

__version__ = "1.2.0"
