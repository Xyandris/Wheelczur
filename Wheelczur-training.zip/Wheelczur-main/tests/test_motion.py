"""Known kinematics, temporal-model math, gaps, and both public CLI workflows."""

from dataclasses import replace
from itertools import product
from pathlib import Path
import csv
import json
import math
import sys

import numpy as np
import pytest

from canine_limb.cli import main
from canine_limb.motion import MotionConfig, analyze_tracking, run_motion
from canine_limb.pipeline import Config, run_video
from canine_limb.runtime import TrackingError
from canine_limb.schema import CSV_FIELDS, LIMBS
from canine_limb.temporal import GaussianPhaseModel


@pytest.fixture
def gait_csv(tmp_path):
    def create(name="gait.csv", count=360, fps=60, limbs=("left-hind",),
               missing=(), translate=False, scale=1.0, amplitude=25.0,
               right_amplitude=None, angle_function=None, drop_frames=()):
        path = tmp_path / name
        with path.open("w", encoding="utf-8-sig", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=CSV_FIELDS)
            writer.writeheader()
            for frame in range(count):
                if frame in drop_frames:
                    continue
                time = frame / fps
                for limb in limbs:
                    amp = right_amplitude if limb.startswith("right") and right_amplitude is not None else amplitude
                    phi = (angle_function(frame) if angle_function else
                           60 + amp * math.sin(2 * math.pi * 1.5 * time))
                    phi = math.radians(phi)
                    root = np.array([100 + (frame * 3 if translate else 0), 80.0]) * scale
                    middle = root + np.array([0, 50]) * scale
                    paw = middle + np.array([50 * math.sin(phi), 50 * math.cos(phi)]) * scale
                    for joint, point in zip(LIMBS[limb][1], (root, middle, paw)):
                        row = {"frame": frame, "time_s": round(time, 9), "limb": limb,
                               "joint": joint, "x_px": point[0], "y_px": point[1],
                               "score": 0.9, "status": "detected"}
                        if frame in missing:
                            row.update(x_px="", y_px="", score=0.1, status="low_confidence")
                        writer.writerow(row)
        return path
    return create


def test_known_frequency_and_projected_angle_range(gait_csv):
    path = gait_csv()
    report, rows = analyze_tracking(path, MotionConfig(smooth_ms=0))
    summary = report["limbs"]["left-hind"]
    angles = summary["joint_angle_deg"]
    assert angles["min"] == pytest.approx(95)
    assert angles["max"] == pytest.approx(145)
    period = summary["periodicity"]
    assert period["status"] == "ok"
    assert period["frequency_hz"] == pytest.approx(1.5, abs=0.04)
    assert period["complete_periods_in_segment"] >= 3
    model = summary["temporal_model"]
    assert model["status"] == "ok"
    means = model["parameters"]["means_deg"]
    assert means[0] < 115 and means[1] > 125
    rows = list(rows)
    assert {row["phase"] for row in rows} == {"more_flexed", "more_extended"}
    assert all(0 <= row["phase_probability"] <= 1 for row in rows)
    assert summary["coverage"] == 1


def test_motion_is_invariant_to_translation_and_uniform_scale(gait_csv):
    stationary, _ = analyze_tracking(gait_csv("fixed.csv"))
    translated, _ = analyze_tracking(gait_csv("translated.csv", translate=True, scale=2))
    a, b = (r["limbs"]["left-hind"] for r in (stationary, translated))
    for field in ("joint_angle_deg", "relative_paw_x_limb_lengths", "relative_paw_speed_limb_lengths_s"):
        assert a[field] == pytest.approx(b[field], abs=1e-9)
    assert b["reference_limb_length_px"] == pytest.approx(2 * a["reference_limb_length_px"])


def test_gaps_do_not_create_velocity_or_smoothing_between_different_poses(gait_csv):
    path = gait_csv(count=90, fps=30, missing=range(40, 50),
                    angle_function=lambda f: 30 if f < 45 else 90)
    report, rows = analyze_tracking(path)
    rows = list(rows)
    assert all(row["angle_deg"] is None and row["phase"] == "unknown" for row in rows[40:50])
    assert rows[39]["angle_deg"] == pytest.approx(150)
    assert rows[50]["angle_deg"] == pytest.approx(90)
    assert rows[39]["relative_paw_speed_limb_lengths_s"] == pytest.approx(0, abs=1e-9)
    assert rows[50]["relative_paw_speed_limb_lengths_s"] == pytest.approx(0, abs=1e-9)
    assert report["limbs"]["left-hind"]["contiguous_segments"] == 2
    assert report["limbs"]["left-hind"]["coverage"] == pytest.approx(80 / 90)


def test_completely_absent_frames_are_gaps_not_long_velocity_intervals(gait_csv):
    report, rows = analyze_tracking(gait_csv(count=90, fps=30, drop_frames=range(40, 50)))
    summary = report["limbs"]["left-hind"]
    assert report["frames_present_in_csv"] == 80 and report["frames_in_span"] == 90
    assert summary["contiguous_segments"] == 2 and summary["missing_or_rejected_frames"] == 10
    assert len(list(rows)) == 80


def test_static_pose_and_no_detections_do_not_invent_cycles(gait_csv):
    for path in (gait_csv("static.csv", amplitude=0), gait_csv("empty.csv", missing=range(360))):
        report, rows = analyze_tracking(path)
        summary = report["limbs"]["left-hind"]
        assert summary["periodicity"]["frequency_hz"] is None
        assert summary["temporal_model"]["status"] != "ok"
        assert {r["phase"] for r in rows} == {"unknown"}
        json.dumps(report, allow_nan=False)


def test_one_frame_has_angles_but_no_speed_or_temporal_predictions(gait_csv):
    report, rows = analyze_tracking(gait_csv(count=1))
    row = next(rows)
    assert report["fps"] is None and row["angle_deg"] == pytest.approx(120)
    assert row["angular_velocity_deg_s"] is None
    assert row["relative_paw_speed_limb_lengths_s"] is None and row["phase"] == "unknown"


def test_timestamp_rounding_does_not_reject_exactly_one_second_of_data(gait_csv):
    report, _ = analyze_tracking(gait_csv(count=60, fps=60))
    assert report["fps"] == 60
    assert report["limbs"]["left-hind"]["temporal_model"]["status"] == "ok"


def test_raw_simcc_scores_are_not_treated_as_probabilities(gait_csv):
    report, _ = analyze_tracking(gait_csv(), MotionConfig(min_confidence=1.2))
    assert report["limbs"]["left-hind"]["complete_joint_frames"] == 0
    path = gait_csv("scores.csv")
    path.write_text(path.read_text(encoding="utf-8-sig").replace(",0.9,detected", ",2.1,detected"), encoding="utf-8")
    report, _ = analyze_tracking(path, MotionConfig(min_confidence=1.2))
    assert report["limbs"]["left-hind"]["coverage"] == 1


def test_symmetry_uses_shared_frames_and_detects_known_range_difference(gait_csv):
    report, _ = analyze_tracking(gait_csv(limbs=("left-hind", "right-hind")), MotionConfig(smooth_ms=0))
    comparison = report["symmetry"]["hind"]
    assert comparison["status"] == "ok"
    assert comparison["angle_range_relative_difference_pct"] == pytest.approx(0, abs=1e-7)
    report, _ = analyze_tracking(gait_csv("asymmetry.csv", limbs=("left-hind", "right-hind"),
                                        right_amplitude=12.5), MotionConfig(smooth_ms=0))
    comparison = report["symmetry"]["hind"]
    assert comparison["angle_range_relative_difference_pct"] == pytest.approx(200 / 3, abs=0.1)
    assert report["symmetry"]["fore"]["status"] == "both_limbs_required"


@pytest.mark.parametrize("change, message", [
    (lambda s: s + s.splitlines()[1] + "\n", "duplicate"),
    (lambda s: s.replace("time_s", "timestamp"), "missing columns"),
    (lambda s: s.replace("0,0.0,left-hind", "0,nan,left-hind"), "finite"),
    (lambda s: s.replace("left-hind,hip", "left-hind,ankle"), "unknown"),
])
def test_invalid_csv_is_rejected(gait_csv, change, message):
    path = gait_csv(count=10)
    path.write_text(change(path.read_text(encoding="utf-8-sig")), encoding="utf-8")
    with pytest.raises(TrackingError, match=message):
        analyze_tracking(path)


def test_fps_override_changes_time_speeds_and_frequency_consistently(gait_csv):
    a, _ = analyze_tracking(gait_csv())
    b, _ = analyze_tracking(gait_csv("override.csv"), MotionConfig(fps=120, smooth_ms=0))
    assert b["duration_between_observations_s"] == pytest.approx(a["duration_between_observations_s"] / 2)
    assert b["limbs"]["left-hind"]["periodicity"]["frequency_hz"] == pytest.approx(3, abs=0.08)


def test_export_collision_and_invalid_input_preserve_existing_results(gait_csv, tmp_path):
    source = gait_csv()
    original_csv = source.read_bytes()
    result = run_motion(source, tmp_path / "analysis")
    before = {p: Path(p).read_bytes() for p in result["outputs"].values()}
    with pytest.raises(TrackingError, match="already exists"):
        run_motion(source, tmp_path / "analysis")
    source.write_text("bad CSV", encoding="utf-8")
    with pytest.raises(TrackingError, match="missing columns"):
        run_motion(source, tmp_path / "analysis", overwrite=True)
    assert all(Path(p).read_bytes() == data for p, data in before.items())
    assert not list((tmp_path / "analysis").glob(".canine-motion-*"))
    source.write_bytes(original_csv)
    result = run_motion(source, tmp_path / "analysis", overwrite=True)
    assert json.loads(Path(result["outputs"]["motion_report"]).read_text())["tracking_csv"] == str(source)


def test_cli_analyzes_existing_csv_without_video_models_or_prompts(gait_csv, tmp_path, monkeypatch, capsys):
    from canine_limb import models
    def forbidden(*args, **kwargs):
        raise AssertionError("Analysis must not load a video model or prompt")
    monkeypatch.setattr(models, "PoseModel", forbidden)
    monkeypatch.setattr(models, "DogDetector", forbidden)
    monkeypatch.setattr("builtins.input", forbidden)
    assert main(["--analyze", str(gait_csv()), "--output-dir", str(tmp_path / "cli")]) == 0
    text = capsys.readouterr().out
    assert "Motion analysis" in text and "HMM ok" in text and "motion_report:" in text
    assert main(["video.mp4", "--analyze", "results.csv"]) == 1


def test_hmm_forward_backward_and_viterbi_match_exhaustive_enumeration():
    model = GaussianPhaseModel()
    model.start = np.array([0.6, 0.4])
    model.transition = np.array([[0.8, 0.2], [0.3, 0.7]])
    model.means, model.variances = np.array([80.0, 120.0]), np.array([100.0, 100.0])
    observations = np.array([85.0, 110.0, 125.0, 100.0])
    posterior, _, likelihood, _ = model._expectation(observations)
    weights = []
    paths = list(product(range(2), repeat=len(observations)))
    for path in paths:
        weight = model.start[path[0]]
        for t, state in enumerate(path):
            if t:
                weight *= model.transition[path[t - 1], state]
            variance = model.variances[state]
            weight *= math.exp(-0.5 * (observations[t] - model.means[state]) ** 2 / variance) / math.sqrt(2 * math.pi * variance)
        weights.append(weight)
    expected = np.zeros_like(posterior)
    for path, weight in zip(paths, weights):
        for t, state in enumerate(path):
            expected[t, state] += weight / sum(weights)
    assert posterior == pytest.approx(expected)
    assert likelihood == pytest.approx(math.log(sum(weights)))
    decoded, _ = model.predict(observations)
    assert tuple(decoded) == paths[int(np.argmax(weights))]


def test_hmm_learns_two_known_postures_reproducibly():
    rng = np.random.default_rng(42)
    states = np.tile(np.repeat([0, 1], 20), 6)
    sequence = np.where(states == 0, 80, 140) + rng.normal(0, 2, len(states))
    a, b = GaussianPhaseModel().fit([sequence]), GaussianPhaseModel().fit([sequence])
    assert a.means == pytest.approx([80, 140], abs=1)
    predicted, _ = a.predict(sequence)
    assert np.array_equal(predicted, states)
    assert a.to_dict() == b.to_dict()


def test_tracking_automatically_analyzes_and_can_skip_motion(make_video, fake_models, tmp_path):
    result = run_video(Config(make_video(), "all", output_dir=tmp_path / "automatic"))
    report = json.loads(Path(result["outputs"]["motion_report"]).read_text())
    assert set(report["limbs"]) == set(LIMBS)
    assert report["tracking_csv"] == result["outputs"]["csv"]
    assert result["motion_analysis_enabled"] is True
    result = run_video(Config(make_video(name="legacy.avi"), "left-hind",
                              output_dir=tmp_path / "legacy", motion=False))
    assert set(result["outputs"]) == {"csv", "video", "metadata"}
    assert result["motion_analysis_enabled"] is False


def test_motion_failure_preserves_all_tracking_outputs(make_video, fake_models, tmp_path, monkeypatch):
    from canine_limb import pipeline
    config = Config(make_video(), "left-hind", output_dir=tmp_path / "failure")
    result = run_video(config)
    before = {p: Path(p).read_bytes() for p in result["outputs"].values()}
    def fail(*args, **kwargs):
        raise TrackingError("motion failed")
    monkeypatch.setattr(pipeline, "write_analysis", fail)
    with pytest.raises(TrackingError, match="motion failed"):
        run_video(replace(config, overwrite=True))
    assert all(Path(p).read_bytes() == data for p, data in before.items())
    assert not list(config.output_dir.glob(".canine-limb-*"))


def test_launcher_exposes_csv_analysis_without_model_or_cuda_check(gait_csv, tmp_path, monkeypatch):
    import launcher
    environment = tmp_path / ".venv-cuda"
    environment.mkdir()
    (environment / "pyvenv.cfg").touch()
    executable = environment / "python"
    executable.touch()
    calls = []
    monkeypatch.setattr(launcher, "environment", lambda device: environment)
    monkeypatch.setattr(launcher, "environment_python", lambda device: executable)
    monkeypatch.setattr(launcher, "require_environment", lambda device: True)
    monkeypatch.setattr(launcher, "run_command", lambda command, **kw: calls.append(command) or True)
    monkeypatch.setattr(launcher, "check_models", lambda *args: pytest.fail("No models needed"))
    assert launcher.main(["--analyze", str(gait_csv())]) == 0
    assert calls[0][2] == "--analyze"


def test_launcher_displays_motion_results_from_real_cli_subprocess(gait_csv, tmp_path, capsys):
    import launcher
    assert launcher.run_command(
        [sys.executable, launcher.ROOT / "track_limb.py", "--analyze", gait_csv(),
         "--output-dir", tmp_path / "streamed"], tracking=True)
    output = capsys.readouterr().out
    assert "Motion analysis" in output and "left-hind:" in output
    assert "motion_csv:" in output and "motion_report:" in output
