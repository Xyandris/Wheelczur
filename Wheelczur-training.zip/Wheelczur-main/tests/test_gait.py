"""Supervised learning, persistence, grouped validation and real CLI workflows.

The artificial classes below are test labels for different waveforms, not
claims that a particular motion amplitude is normal or abnormal in real dogs.
"""

from pathlib import Path
import csv
import json
import math
import shutil
import subprocess
import sys

import numpy as np
import pytest

from canine_limb.cli import main
from canine_limb.dataset import add_sample, collect_samples, prepare_tracking_csv
from canine_limb.gait import (LABELS, features_from_csv, load_model, model_scores, predict_csv,
                              print_prediction, train_classifier)
from canine_limb.runtime import TrackingError
from canine_limb.schema import CSV_FIELDS, LIMBS


@pytest.fixture
def recording(tmp_path):
    def create(path=None, amplitude=25, phase=0, offset=0, missing=(), count=90, limbs=tuple(LIMBS)):
        path = Path(path) if path is not None else tmp_path / "new.csv"
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("w", encoding="utf-8-sig", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=CSV_FIELDS)
            writer.writeheader()
            for frame in range(count):
                for i, limb in enumerate(limbs):
                    t = frame / 30
                    phi = math.radians(60 + amplitude * math.sin(2 * math.pi * 1.5 * t + phase + i * 0.3))
                    root = np.array([100 + offset + 0.2 * frame + i * 10, 80.0])
                    middle = root + [0, 50]
                    paw = middle + [50 * math.sin(phi), 50 * math.cos(phi)]
                    for joint, point in zip(LIMBS[limb][1], (root, middle, paw)):
                        valid = frame not in missing
                        writer.writerow({"frame": frame, "time_s": round(t, 9), "limb": limb, "joint": joint,
                                         "x_px": point[0] if valid else "", "y_px": point[1] if valid else "",
                                         "score": 0.9 if valid else 0.1, "status": "detected" if valid else "low_confidence"})
        return path
    return create


@pytest.fixture
def labelled_dataset(tmp_path, recording):
    root = tmp_path / "dataset"
    for i in range(3):
        for label, amplitude in zip(LABELS, (24 + i, 5 + i)):
            recording(root / label / f"dog{i}" / f"clip{i}.csv", amplitude=amplitude, phase=i * 0.13, offset=i * 10)
    return root


def test_training_saves_model_and_classifies_unseen_recordings(labelled_dataset, recording, tmp_path):
    model_path = tmp_path / "model.json"
    trained = train_classifier(labelled_dataset, model_path)
    model = load_model(model_path)
    assert model == trained
    assert model["training"]["samples"] == 6 and model["training"]["dogs"] == 3
    assert model["training"]["class_counts"] == dict(zip(LABELS, (3, 3)))
    normal = recording(tmp_path / "unseen_normal.csv", amplitude=24.5, phase=0.5, offset=400)
    abnormal = recording(tmp_path / "unseen_abnormal.csv", amplitude=6.5, phase=0.5, offset=400)
    assert predict_csv(normal, model)["label"] == "prawidlowy"
    assert predict_csv(abnormal, model)["label"] == "nieprawidlowy"
    assert model["training"]["validation"]["metrics"]["balanced_accuracy"] == 1
    assert model["features"] and len(model["parameters"]["weights"]) == len(model["features"])


def test_labels_actually_teach_the_model_instead_of_fixed_thresholds(labelled_dataset, recording, tmp_path):
    normal = recording(tmp_path / "unseen.csv", amplitude=25, phase=0.8)
    first = train_classifier(labelled_dataset, tmp_path / "first.json")
    flipped = tmp_path / "flipped"
    for label, opposite in zip(LABELS, reversed(LABELS)):
        shutil.copytree(labelled_dataset / label, flipped / opposite)
    second = train_classifier(flipped, tmp_path / "second.json")
    assert predict_csv(normal, first)["label"] == "prawidlowy"
    assert predict_csv(normal, second)["label"] == "nieprawidlowy"


def test_validation_keeps_every_dog_out_of_its_training_fold(labelled_dataset, tmp_path):
    model = train_classifier(labelled_dataset, tmp_path / "model.json")
    validation = model["training"]["validation"]
    assert validation["status"] == "ok" and validation["evaluated_samples"] == 6
    for fold in validation["folds"]:
        assert not set(fold["train_dogs"]) & set(fold["test_dogs"])
        assert len(fold["test_dogs"]) == 1 and fold["test_samples"] == 2


def test_same_dog_can_train_but_does_not_get_fake_validation_score(labelled_dataset, tmp_path):
    for label in LABELS:
        combined = labelled_dataset / label / "same_dog"
        combined.mkdir()
        for path in list((labelled_dataset / label).glob("dog*/*.csv")):
            shutil.move(path, combined / path.name)
    model = train_classifier(labelled_dataset, tmp_path / "model.json")
    assert model["training"]["validation"]["metrics"] is None
    assert model["training"]["validation"]["status"] == "insufficient_dogs"
    assert model["training"]["notes"]


def test_classes_segregated_by_dog_do_not_get_a_fake_validation_score(labelled_dataset, tmp_path):
    for label in LABELS:
        destination = labelled_dataset / label / ("dog_normal" if label == LABELS[0] else "dog_abnormal")
        destination.mkdir()
        for path in list((labelled_dataset / label).glob("dog[0-9]/*.csv")):
            shutil.move(path, destination / path.name)
    model = train_classifier(labelled_dataset, tmp_path / "model.json")
    assert model["training"]["validation"]["status"] == "insufficient_class_distribution_by_dog"
    assert model["training"]["validation"]["metrics"] is None


def test_adding_and_retraining_uses_all_examples(labelled_dataset, recording, tmp_path):
    path = tmp_path / "model.json"
    first = train_classifier(labelled_dataset, path)
    for label, amp in zip(LABELS, (28, 8)):
        source = recording(tmp_path / f"{label}.csv", amplitude=amp, phase=0.6)
        result = add_sample(source, label, "dog_new", labelled_dataset)
        assert result["status"] == "added" and Path(result["path"]).is_file()
    second = train_classifier(labelled_dataset, path)
    assert first["training"]["samples"] == 6 and second["training"]["samples"] == 8
    assert load_model(path)["training"]["class_counts"] == dict(zip(LABELS, (4, 4)))


def test_duplicate_copies_do_not_count_as_new_samples(labelled_dataset, tmp_path):
    original = next((labelled_dataset / LABELS[0]).glob("*/*.csv"))
    copied = tmp_path / "copy.csv"
    shutil.copyfile(original, copied)
    result = add_sample(copied, LABELS[0], "another_dog", labelled_dataset)
    assert result["status"] == "already_added"
    with pytest.raises(TrackingError, match="przeciwna etykieta"):
        add_sample(copied, LABELS[1], "another_dog", labelled_dataset)
    duplicate = labelled_dataset / LABELS[0] / "another_dog" / "duplicate.csv"
    duplicate.parent.mkdir()
    shutil.copyfile(original, duplicate)
    model = train_classifier(labelled_dataset, tmp_path / "model.json")
    assert model["training"]["samples"] == 6
    assert len(model["training"]["skipped_duplicates"]) == 1


def test_contradictory_labels_abort_without_replacing_existing_model(labelled_dataset, tmp_path):
    path = tmp_path / "model.json"
    train_classifier(labelled_dataset, path)
    before = path.read_bytes()
    source = next((labelled_dataset / LABELS[0]).glob("*/*.csv"))
    duplicate = labelled_dataset / LABELS[1] / "dog_bad" / "contradiction.csv"
    duplicate.parent.mkdir()
    shutil.copyfile(source, duplicate)
    with pytest.raises(TrackingError, match="sprzeczne etykiety"):
        train_classifier(labelled_dataset, path)
    assert path.read_bytes() == before
    assert not list(tmp_path.glob(".gait-model-*"))


def test_both_classes_and_distinct_recordings_are_required(recording, tmp_path):
    root = tmp_path / "few"
    source = recording()
    add_sample(source, LABELS[0], "dog1", root)
    with pytest.raises(TrackingError, match="2 ROZNYCH"):
        train_classifier(root, tmp_path / "model.json")
    assert not (tmp_path / "model.json").exists()


def test_uninformative_identical_features_are_not_a_trained_classifier(recording, tmp_path):
    root = tmp_path / "no_signal"
    for i in range(4):
        recording(root / LABELS[i % 2] / f"dog{i}" / "clip.csv", offset=i * 5)
    with pytest.raises(TrackingError, match="identyczne cechy"):
        train_classifier(root, tmp_path / "model.json")


def test_bad_observations_and_incompatible_limbs_do_not_get_a_binary_verdict(labelled_dataset, recording, tmp_path):
    model = train_classifier(labelled_dataset, tmp_path / "model.json")
    missing = recording(tmp_path / "missing.csv", missing=range(60))
    still = recording(tmp_path / "still.csv", amplitude=0)
    single = recording(tmp_path / "single.csv", limbs=("left-fore",))
    for path in (missing, still, single):
        result = predict_csv(path, model)
        assert result["status"] == "insufficient_data" and result["label"] is None


def test_uncertain_scores_are_not_displayed_as_normal(labelled_dataset, recording, tmp_path, capsys):
    model = train_classifier(labelled_dataset, tmp_path / "model.json")
    model["parameters"]["weights"] = [0.0] * len(model["features"])
    model["parameters"]["intercept"] = 0.0
    result = predict_csv(recording(), model)
    assert result["status"] == "uncertain" and result["label"] is None
    print_prediction(result)
    assert capsys.readouterr().out.startswith("BRAK OCENY:")


@pytest.mark.parametrize("damage", [
    lambda m: m.update(model_version=99),
    lambda m: m.update(features=["different_schema"]),
    lambda m: m["parameters"]["scale"].__setitem__(0, 0),
    lambda m: m["parameters"]["weights"].__setitem__(0, float("nan")),
    lambda m: m.update(format="motion_report"),
])
def test_corrupt_models_are_rejected(labelled_dataset, tmp_path, damage):
    path = tmp_path / "model.json"
    model = train_classifier(labelled_dataset, path)
    damage(model)
    path.write_text(json.dumps(model), encoding="utf-8")
    with pytest.raises(TrackingError, match="Niepoprawny model"):
        load_model(path)


def test_saved_numpy_inference_matches_sklearn_training(labelled_dataset, tmp_path):
    from sklearn.linear_model import LogisticRegression
    from sklearn.preprocessing import StandardScaler
    model = train_classifier(labelled_dataset, tmp_path / "model.json")
    samples = collect_samples(labelled_dataset)
    matrix = np.stack([features_from_csv(s["path"])[0] for s in samples])
    targets = np.array([LABELS.index(s["label"]) for s in samples])
    scaler = StandardScaler().fit(matrix)
    classifier = LogisticRegression(C=1, class_weight="balanced", solver="lbfgs", max_iter=2000, random_state=0)
    classifier.fit(scaler.transform(matrix), targets)
    assert model_scores(model["parameters"], matrix) == pytest.approx(
        classifier.predict_proba(scaler.transform(matrix))[:, 1], abs=1e-12)


def test_persisted_prediction_runs_in_a_fresh_process_without_sklearn(labelled_dataset, recording, tmp_path):
    model = tmp_path / "model.json"
    train_classifier(labelled_dataset, model)
    source = recording(tmp_path / "fresh.csv", amplitude=25, phase=0.8)
    code = ("import sys; sys.modules['sklearn'] = None; "
            "from canine_limb.cli import main; raise SystemExit(main(sys.argv[1:]))")
    result = subprocess.run([sys.executable, "-c", code, "--predict", str(source), "--gait-model", str(model)],
                            cwd=Path(__file__).resolve().parents[1], capture_output=True, text=True)
    assert result.returncode == 0, result.stderr
    assert result.stdout.strip() == "RUCH PRAWIDŁOWY"


def test_single_limb_training_and_prediction_are_supported(recording, tmp_path):
    dataset = tmp_path / "single_limb"
    for i in range(4):
        recording(dataset / LABELS[i % 2] / f"dog{i}" / "clip.csv", amplitude=25 if i % 2 == 0 else 6,
                  phase=i * 0.15, limbs=("left-fore",))
    model = train_classifier(dataset, tmp_path / "single.json", limb="left-fore")
    source = recording(tmp_path / "single_unseen.csv", amplitude=25, phase=0.6, limbs=("left-fore",))
    assert predict_csv(source, model)["label"] == LABELS[0]
    assert len(model["features"]) == 9


def test_add_sample_handles_an_empty_precreated_dataset(recording, tmp_path):
    dataset = tmp_path / "empty"
    (dataset / LABELS[0]).mkdir(parents=True)
    result = add_sample(recording(), LABELS[0], "Rex", dataset)
    assert result["status"] == "added" and result["dog_id"] == "rex"
    with pytest.raises(TrackingError, match="Identyfikator"):
        add_sample(recording(), LABELS[0], "../outside", dataset)


def test_fps_override_is_kept_in_added_training_samples(recording, tmp_path):
    source = recording()
    original = source.read_bytes()
    result = add_sample(source, LABELS[0], "dog1", tmp_path / "dataset", tracking_options={"fps": 60})
    first, a = features_from_csv(source)
    second, b = features_from_csv(result["path"])
    assert source.read_bytes() == original
    assert a["fps"] == 30 and b["fps"] == 60
    assert b["duration_between_observations_s"] == pytest.approx(a["duration_between_observations_s"] / 2)
    assert second[6] > first[6]  # the retimed recording has a greater relative paw speed


def test_video_preprocessing_is_cached_and_corruption_invalidates_cache(make_video, fake_models, monkeypatch, tmp_path):
    pose, _ = fake_models
    calls = []
    def moving(self, frame, box):
        self.calls += 1
        calls.append(self.calls)
        phi = math.radians(60 + 25 * math.sin(self.calls * math.pi / 10))
        points, scores = np.full((17, 2), 100, dtype=float), np.full(17, 0.9)
        for indices, _ in LIMBS.values():
            points[list(indices)] = [(120, 70), (120, 110), (120 + 40 * math.sin(phi), 110 + 40 * math.cos(phi))]
        return points, scores
    monkeypatch.setattr(pose, "predict", moving)
    video = make_video(count=60, fps=30)
    cache = tmp_path / "cache"
    first = prepare_tracking_csv(video, cache)
    assert first.is_file() and len(calls) == 60
    assert prepare_tracking_csv(video, cache) == first and len(calls) == 60
    assert features_from_csv(first)[0].shape == (40,)
    first.write_bytes(b"corrupt cache")
    prepare_tracking_csv(video, cache)
    assert len(calls) == 120
    result = add_sample(video, LABELS[0], "dog1", tmp_path / "dataset")
    assert result["status"] == "added"
    assert Path(result["path"]).suffix == ".csv"
    assert not list(cache.glob(".prepare-gait-*"))


def test_cli_train_predict_and_existing_analysis_display_verdict(labelled_dataset, recording, tmp_path, capsys):
    model = tmp_path / "model.json"
    assert main(["--train", "--dataset", str(labelled_dataset), "--gait-model", str(model)]) == 0
    assert "Trening zakonczony" in capsys.readouterr().out
    source = recording(tmp_path / "new.csv", amplitude=6, phase=0.8)
    assert main(["--predict", str(source), "--gait-model", str(model)]) == 0
    assert capsys.readouterr().out.strip() == "RUCH NIEPRAWIDŁOWY"
    assert main(["--analyze", str(source), "--gait-model", str(model), "--output-dir", str(tmp_path / "analysis")]) == 0
    assert "RUCH NIEPRAWIDŁOWY" in capsys.readouterr().out
    assert main(["--predict", str(source), "--gait-model", str(tmp_path / "absent.json")]) == 1


def test_cli_add_requires_explicit_label_and_dog(recording, tmp_path, capsys):
    path = recording()
    assert main(["--add-sample", str(path), "--dataset", str(tmp_path / "dataset")]) == 1
    assert "--dog-id" in capsys.readouterr().err
    assert main(["--add-sample", str(path), "--label", LABELS[0], "--dog-id", "rex",
                 "--dataset", str(tmp_path / "dataset")]) == 0


def test_launcher_train_and_predict_use_real_child_cli(labelled_dataset, recording, tmp_path, monkeypatch, capsys):
    import launcher
    monkeypatch.setattr(launcher, "require_environment", lambda device: True)
    monkeypatch.setattr(launcher, "environment_python", lambda device: Path(sys.executable))
    monkeypatch.setattr(launcher, "check_models", lambda *a, **kw: pytest.fail("CSV learning needs no ONNX weights"))
    model = tmp_path / "model.json"
    assert launcher.main(["--train", "--dataset", str(labelled_dataset), "--gait-model", str(model)]) == 0
    assert "Model zapisany:" in capsys.readouterr().out
    source = recording(tmp_path / "launcher.csv", amplitude=25, phase=0.8)
    assert launcher.main(["--predict", str(source), "--gait-model", str(model)]) == 0
    assert "RUCH PRAWIDŁOWY" in capsys.readouterr().out


def test_launcher_collects_label_and_dog_before_starting_child(recording, monkeypatch):
    import launcher
    source = recording()
    answers = iter(["10", str(source), "2", "dog1", "all", "0"])
    monkeypatch.setattr("builtins.input", lambda prompt: next(answers))
    monkeypatch.setattr(launcher, "require_environment", lambda device: True)
    calls = []
    monkeypatch.setattr(launcher, "run_command", lambda command, **kw: calls.append(command) or True)
    assert launcher.main([]) == 0
    assert "--add-sample" in calls[0] and "nieprawidlowy" in calls[0] and "dog1" in calls[0]
