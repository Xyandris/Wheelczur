# Analiza projektu i rozszerzenia 1.1–1.2

## Zmiany w wersji 1.2: model uczony na wielu nagraniach

Dodano nadzorowany klasyfikator prawidłowego/nieprawidłowego ruchu, który uczy się z etykiet użytkownika. Korzysta z 9 cech na kończynę oraz 4 cech porównania stron dla `all`, standaryzacji i regularyzowanej regresji logistycznej. Całe nagranie jest jednym przykładem. Model i parametry przygotowania cech są zapisywane w `gait_model.json` i ponownie wczytywane podczas oceny nowego nagrania.

`canine_limb/dataset.py` obsługuje dodawanie filmów i oryginalnych CSV, ID psów, zachowanie punktów do kolejnych treningów, korektę FPS i weryfikowany cache. `canine_limb/gait.py` zawiera cechy, trening, walidację według psów, walidację modelu JSON i ocenę. `canine_limb/cli.py` oraz launcher otrzymały opcje dodawania danych, treningu i oceny; w menu są to **10, 11 i 12**. Po treningu dotychczasowe śledzenie i analiza CSV również mogą dopisać ocenę.

Trening wymaga obu klas i co najmniej dwóch różnych nagrań na klasę. Dokładne kopie są pomijane; sprzeczne etykiety tego samego CSV przerywają trening. Wszystkie nagrania jednego psa pozostają w jednej części walidacji, a standaryzator jest uczony na każdej części treningowej osobno. Jeśli niezależna walidacja nie jest możliwa, program nie pokazuje fikcyjnej trafności. Trening aktualizuje zapisany model dopiero po sukcesie.

Brak obserwacji, zbyt mała kompletność danych, niezgodne kończyny lub niepewna decyzja dają **BRAK OCENY**. Nie wytrenowano modelu na arbitralnie oznaczonym filmie demonstracyjnym. Wynik po treningu oznacza klasę względem dostarczonych etykiet, a nie potwierdzenie stanu zdrowia. Instrukcja użytkownika: [docs/TRAINING.md](docs/TRAINING.md).

Nowe testy w `tests/test_gait.py` sprawdzają uczenie na znanych sztucznych klasach, zamianę etykiet, trening ponowny z dodatkowymi danymi, zapis i odczyt, ocenę w osobnym procesie, rozdzielenie psów podczas walidacji, obsługę duplikatów i sprzeczności, odrzucanie uszkodzonych modeli, cache wideo oraz rzeczywiste wywołania CLI przez launcher. Są to testy poprawności oprogramowania, nie walidacja skuteczności klinicznej.

Weryfikacja 1.2: **99 testów zaliczonych, 1 pominięty (CUDA)** z oryginalnymi wagami oraz **97 zaliczonych, 3 pominięte** po rozpakowaniu wydania bez wag. Budowa wheel 1.2 zakończyła się powodzeniem. Nowa ścieżka przygotowania dołączonego rzeczywistego filmu wygenerowała 40 skończonych cech. Oddzielny test uruchomionej wersji z ZIP-a przeszedł pełny cykl: dodanie 6 sztucznych nagrań, trening, zapis modelu i dwie oceny w kolejnych procesach launchera. Ten test CSV działał także bez OpenCV i wag ONNX; nie nadaje filmowi demonstracyjnemu etykiety biologicznej.

## Stan wejściowy

Projekt miał poprawnie oddzielone etapy: `launcher.py` zarządzał środowiskami CPU/CUDA, `download_models.py` pobierał i weryfikował modele, a `canine_limb` wykonywał detekcję, estymację punktów, wybór psa oraz eksport danych. `track_limb.py`, `python -m canine_limb` i polecenie `canine-limb` prowadzą do tego samego CLI.

YOLOX-Tiny wykrywa psa. RTMPose AP-10K wyznacza 17 punktów, z których eksportowane są trzy punkty każdej wybranej kończyny. Poprzednia wersja nie modelowała zależności między kolejnymi klatkami: eksportowała punkty, ich statusy i film z oznaczeniami. CSV zawiera już czas i score, dlatego można dodać analizę ruchu bez zmieniania sieci obrazu i bez powtarzania kosztownej inferencji.

Zachowano format surowego CSV, strony anatomiczne psa, działanie CPU/CUDA, pobieranie modeli oraz obsługę CLI. Wagi ONNX i środowiska nadal nie są częścią archiwum źródłowego.

## Zmiany w wersji 1.1

| Plik | Rola zmiany |
| --- | --- |
| `canine_limb/temporal.py` | Nowy dwu-stanowy gaussowski HMM: uczenie EM, forward–backward, Viterbi, zapis parametrów |
| `canine_limb/motion.py` | Odczyt i walidacja poprzednich CSV, kinematyka 2D, normalizacja, okresowość, porównanie stron, raporty |
| `canine_limb/pipeline.py` | Automatyczne uruchomienie analizy po eksporcie punktów; wspólne przygotowanie wyników przed publikacją |
| `canine_limb/cli.py` | `--analyze`, `--no-motion`, `--motion-confidence`, `--motion-smooth-ms` i podsumowanie w terminalu |
| `launcher.py` | Opcja 9 oraz `--analyze TRACKING_CSV`, bez sprawdzania wag i GPU przy analizie CSV |
| `tests/test_motion.py` | Testy znanego ruchu, modelu, luk, geometrii, porównania stron, eksportu oraz obu ścieżek CLI |
| `tests/test_real_models_and_cli.py` | Jawny wybór metadanych `*_run.json`; pomijanie testów wag, gdy nie zostały pobrane |
| `README.md`, `docs/MOTION.md` | Instrukcja użycia, definicje pomiarów i ograniczenia |
| `examples/doggi-walk-01_all.csv` | Eksport punktów z filmu dołączonego do projektu, gotowy do demonstracji `--analyze` |

Nowy HMM jest modelem statystycznym uczącym się lokalnego wzorca względnego zgięcia/wyprostu na danym filmie. Nie wymaga dodatkowej biblioteki ani dodatkowych wag. W repozytorium nie ma oznaczonego zbioru diagnoz ani typów chodu; nie dodano więc pozornego klasyfikatora zdrowia z arbitralnymi etykietami.

## Co wymaga ostrożnej interpretacji

Identyfikacja psa opiera się na przestrzennym dopasowaniu ramek; przy wielu podobnych psach możliwa jest zmiana tożsamości. Nowa analiza dziedziczy tę własność i nie naprawia błędnych punktów. Nie zmienia też lewej/prawej strony przy zasłonięciach. Jakość wyniku zależy od materiału wejściowego i jakości detekcji.

Pomiar jest projekcją 2D, a „faza” oznacza względną pozycję kończyny według HMM. Nie jest to kontakt z podłożem, wykrycie choroby ani wynik badania klinicznego. Parametryczne progi jakości w kodzie służą stabilności obliczeń i nie są normami dla psów.

Warstwa analizy przechowuje w pamięci współrzędne i wyniki czasowe; jej pamięć rośnie z liczbą klatek i kończyn. Wczytywanie samego filmu przez tracker pozostało strumieniowe. Dla wielogodzinnych filmów dalszym krokiem byłoby przetwarzanie i dopasowywanie modelu w oknach.

Oryginalny `pyproject.toml` wymienia nieobecne w przesłanym ZIP-ie pliki `LICENSE` i `THIRD_PARTY_NOTICES.md`. Obecnie budowa pakietu kończy się powodzeniem z ostrzeżeniami o tych brakach. Nie zmieniano deklaracji autorstwa/licencji projektu; do publicznej dystrybucji warto uzupełnić pliki u źródła.

## Weryfikacja wersji 1.1

Zestaw testów sprawdza między innymi:

- Odzyskanie częstotliwości 1,5 Hz i znanych granic kąta 95–145° z syntetycznej trajektorii.
- Niezmienność miar względnych po translacji i jednolitym skalowaniu.
- Brak interpolacji, wygładzania i liczenia prędkości przez luki.
- Brak wymyślonych faz lub okresów przy nieruchomych punktach i braku detekcji.
- Zgodność forward–backward i Viterbiego z wyczerpującym przeliczeniem wszystkich ścieżek małego HMM.
- Wykrywanie różnicy zakresu kątów dla znanej różnicy amplitudy obu kończyn.
- Ochronę istniejących plików przy błędzie analizy i działanie bezpośredniego CLI oraz launchera.

Polecenie testów po zainstalowaniu dodatkowych zależności testowych:

```bash
python -m pip install -e ".[cpu,test]"
python -m pytest -q
```

Testy oryginalnych modeli wymagają uprzedniego `python launcher.py --models`. Bez wag są jawnie pomijane; pozostałe testy korzystają z kontrolowanych danych. Test CUDA pozostaje opcjonalny i wymaga odpowiedniego sprzętu.

Weryfikacja CPU zakończyła się wynikiem **72 testy zaliczone, 1 pominięty (CUDA)**. Objęła też pełne uruchomienie oryginalnych modeli na `test-vid/doggi-walk-01.mp4`: 114 klatek, 1368 obserwacji punktów, raporty dla czterech kończyn i poprawne dopasowanie HMM. Analiza tego samego CSV przez `--analyze` dała zgodne numerycznie pomiary i identyczne parametry HMM; bardzo małe różnice pochodnych wynikają z zaokrąglenia czasu w źródłowym CSV. Nie oceniano poprawności biologicznej wykrytych punktów względem ręcznych etykiet. Budowa pakietu wheel również zakończyła się powodzeniem; ostrzeżenia o istniejących brakach licencyjnych opisano powyżej.
