# Nauka oceny ruchu w Wheelczur 1.2

## Co jest uczone

Nowy klasyfikator uczy się rozróżnienia **prawidlowy / nieprawidlowy** na podstawie Twoich oznaczeń całych nagrań. Ma trwały zapis w `gait_model.json`, który jest ładowany przy ocenie kolejnego filmu. Dotychczasowy HMM nadal opisuje względne fazy kończyn w każdym filmie; klasyfikator jest osobną warstwą nad pomiarami ruchu.

Nie dostarczono zbioru filmów z pewnymi etykietami obu klas. Archiwum zawiera działający trening i ocenę, ale przed pierwszą oceną musisz dodać własne oznaczone przykłady i wykonać trening. Żadne dołączone nagranie nie zostało arbitralnie uznane za prawidłowe lub nieprawidłowe.

## Najprostsza obsługa w menu

1. Rozpakuj nową wersję projektu. Uruchom ją poleceniem **`python launcher.py`**, nie samą nazwą pliku. Możesz zachować istniejące `.venv-cpu`, `.venv-cuda` i pobrane wagi w ich dotychczasowych miejscach.
2. Wybierz **1** dla aktualizacji środowiska CPU lub **2** dla CUDA. Instalacja doda scikit-learn. Nowa biblioteka jest potrzebna do treningu; nie pobiera dodatkowego gotowego modelu oceny ruchu.
3. Wybierz **10**. Podaj film albo oryginalny CSV z punktami. Wybierz etykietę: **1 = ruch prawidłowy, 2 = ruch nieprawidłowy**. Podaj ID psa, np. `pies01`, i kończyny, domyślnie `all`.
4. Powtarzaj dodawanie dla kolejnych przykładów obu klas. Minimum techniczne to **2 różne nagrania na klasę**; kopie tego samego CSV nie zwiększają liczby przykładów. Tak mały zbiór służy sprawdzeniu działania, nie potwierdzeniu skuteczności na nowych psach.
5. Wybierz **11**, a następnie ten sam zakres kończyn. Program przeliczy cały zbiór, pokaże wynik dostępnej walidacji i zapisze model. Po udanym treningu nie trzeba niczego kopiować z raportu.
6. Wybierz **12** i podaj film lub CSV do oceny. Program wypisze **RUCH PRAWIDŁOWY**, **RUCH NIEPRAWIDŁOWY** albo **BRAK OCENY** z przyczyną.

Opcja 10 zapisuje punkty w zarządzanym katalogu treningowym, więc oryginalny film lub CSV może później zostać przeniesiony. Przy bezpośrednim dodaniu filmu program najpierw uruchamia istniejące modele wyznaczania punktów. Nie modyfikuje źródłowego nagrania. Opcje menu korzystają z CPU do wyznaczania punktów; CUDA można wybrać flagą `--learning-device cuda`.

Dodajesz kolejne przykłady opcją **10**, potem ponawiasz **11**. Wszystkie dotychczasowe przykłady pozostają w zbiorze. Model jest zapisywany dopiero po udanym treningu; błąd nie zastępuje poprzedniego pliku modelu.

## Wcześniejsze CSV jednej kończyny

Jeśli masz już pliki w rodzaju `doggi-walk-01_left_fore.csv`, nie musisz ponownie mapować punktów. Dodawaj je i ucz model z `left-fore`:

```bash
python launcher.py --add-sample "dane/dobry_01_left_fore.csv" --label prawidlowy --dog-id pies01 --limb left-fore
python launcher.py --add-sample "dane/zly_01_left_fore.csv" --label nieprawidlowy --dog-id pies02 --limb left-fore
# Dołóż dalsze przykłady: minimum dwa różne w każdej klasie.
python launcher.py --train --limb left-fore
python launcher.py --predict "dane/nowy_left_fore.csv"
```

Model `all` wymaga wszystkich czterech kończyn. Model `left-fore` wymaga tylko tej kończyny i ocenia zakres obserwacji opisany przez te punkty. CSV ze śledzenia wszystkich kończyn może być użyty do uczenia modelu jednej kończyny. CSV z jednej kończyny nie wystarczy modelowi `all`.

Wejściem jest **oryginalny CSV z punktami**. Pliki `*_motion.csv`, `*_motion.json` i `*_run.json` nie są przykładami treningowymi ani wejściem do oceny.

## Polecenia bez menu

```bash
# Dodawanie filmów lub oryginalnych CSV
python launcher.py --add-sample "filmy/poprawny_01.mp4" --label prawidlowy --dog-id pies01
python launcher.py --add-sample "filmy/niepoprawny_01.mp4" --label nieprawidlowy --dog-id pies02

# Uczenie po dodaniu odpowiedniej liczby przykładów
python launcher.py --train

# Ocena nowego nagrania lub oryginalnego CSV
python launcher.py --predict "filmy/do_oceny.mp4"
python launcher.py --predict "wyniki/do_oceny_all.csv"

# CUDA do wyznaczania punktów w filmie
python launcher.py --predict "filmy/do_oceny.mp4" --learning-device cuda

# Własny zbiór i osobny model
python launcher.py --train --dataset "dane_treningowe" --gait-model "modele/moj_model.json"
python launcher.py --predict "film.mp4" --gait-model "modele/moj_model.json"
```

Te same akcje są dostępne bezpośrednio przez `track_limb.py` w zainstalowanym środowisku. Bezpośrednie CLI udostępnia dodatkowo `--motion-smooth-ms`, `--motion-confidence`, `--fps`, `--bbox`, `--dog-index`, `--models-dir` i `--decision-confidence`. Wygładzanie i próg cech są zapisywane z modelem, a ocena korzysta z zapisanych wartości. `--fps` przy ocenie służy świadomej korekcie czasu; zmiana FPS zmienia również cechy prędkości. Ustawienia wyboru psa/kadru odnoszą się do konkretnego przetwarzanego filmu.

## Dane i trwałość

Domyślny zbiór to `training_data`, domyślny model to `gait_model.json` w folderze projektu. Dodawanie przez opcję 10 tworzy podfoldery automatycznie. Można też przygotować katalog samodzielnie, umieszczając filmy lub CSV bezpośrednio w folderze danego psa:

| Przykładowa ścieżka | Znaczenie |
| --- | --- |
| `training_data/prawidlowy/pies01/film01.csv` | Poprawny ruch, pies o ID `pies01` |
| `training_data/prawidlowy/pies02/film02.mp4` | Poprawny ruch, inny pies |
| `training_data/nieprawidlowy/pies01/film03.csv` | Niepoprawny ruch tego samego `pies01`, np. w innej sesji |
| `training_data/nieprawidlowy/pies03/film04.mp4` | Niepoprawny ruch psa o ID `pies03` |

ID oznacza rzeczywistego psa, nie numer filmu. Dla wszystkich sesji i obu klas tego samego psa używaj jednego ID. Wielkość liter w ID nie rozróżnia psów. Nagrania z wielu psów trzeba wcześniej rozdzielić lub wskazać właściwego psa przez bezpośrednie CLI.

Folder `.cache` w zbiorze oraz `.gait-cache` obok modelu zawierają zapis punktów z filmów. Cache jest weryfikowany sumą kontrolną, a zmiana zawartości źródła lub ustawień wyznaczania punktów powoduje ponowne przetwarzanie. Usunięcie cache nie usuwa modelu ani przykładów dodanych przez opcję 10. Ręcznie dodane filmy muszą pozostać dostępne podczas treningu.

Błędną etykietę poprawisz, przenosząc CSV do folderu właściwej klasy i zachowując ID psa. Potem wykonaj trening ponownie. Program blokuje identyczne CSV z przeciwnymi etykietami i pomija wielokrotne kopie tego samego eksportu. Nie wykryje wszystkich kopii ponownie zakodowanego wideo ani błędnie wpisanych ID psów.

## Jak działa model i sprawdzanie wyniku

Klasyfikator to regresja logistyczna z regularyzacją L2 i wyrównaniem wag klas. Cechy są standaryzowane na zbiorze treningowym. Dla każdej kończyny używane są: średni kąt, zakres P95–P05, średnia i P95 prędkości kątowej, wychylenie x/y łapy, średnia i P95 prędkości względnej łapy oraz zmienność tej prędkości. Model `all` zawiera również cztery cechy różnic między stronami. Czas filmu, pokrycie detekcji i nazwa pliku nie są cechami klasyfikatora.

Każde nagranie jest jednym przykładem. **Walidacja rozdziela psy**, a nie losowe klatki: wszystkie filmy jednego psa są razem w części uczącej albo sprawdzającej. Skalowanie cech także jest uczone osobno w każdym podziale. Jeśli rozkład klas i psów nie pozwala przeprowadzić pełnej walidacji, program to zgłasza i nie pokazuje pozornej trafności. Zapis obejmuje metryki, macierz pomyłek, ID grup w podziałach i listę użytych źródeł.

Po walidacji końcowy model jest uczony na wszystkich przykładach. Przy kolejnej ocenie jego średnie, skale i współczynniki są wczytywane z walidowanego JSON-a. Nie jest używany pickle ani wykonywanie kodu z pliku modelu. Wnioskowanie z CSV wymaga tylko NumPy; scikit-learn jest potrzebny podczas treningu.

### Kiedy pojawi się BRAK OCENY

- Wymagana kończyna jest nieobecna albo ma mniej niż sekundę poprawnych obserwacji lub mniej niż 60% pokrycia.
- Nie ma ciągłych obserwacji pozwalających zmierzyć prędkości albo wystarczającego ruchu kończyn.
- Model `all` nie ma wystarczająco dużo wspólnych klatek do porównania stron.
- Wynik klasyfikatora znajduje się w strefie niepewnej: domyślnie zwycięska klasa musi mieć wynik co najmniej 0,6. To wewnętrzny wynik modelu, nie skalibrowane prawdopodobieństwo stanu zdrowia.

Niepoprawny CSV, brak wytrenowanego modelu lub uszkodzony plik modelu powoduje czytelny błąd, zamiast losowego przypisania klasy.

## Interpretacja i ograniczenia

Etykiety muszą pochodzić z niezależnej oceny materiału. Model odtwarza zależności w Twoich oznaczeniach; nie ustala sam, jakie zachowanie jest prawidłowe. Niewielki lub jednostronny zbiór może nauczyć model prędkości, kąta kamery, rasy albo sposobu nagrywania zamiast poszukiwanej cechy ruchu. Zbieraj porównywalne ujęcia obu klas i sprawdzaj model na innych psach. Zmiany perspektywy, zasłanianie łap i błędy mapowania mogą wpływać na wynik nawet przy wysokim score.

Komunikaty „ruch prawidłowy/nieprawidłowy” są **oceną wytrenowanego prototypu względem jego danych**, nie diagnozą choroby. Nie przeprowadzono walidacji klinicznej ani badania skuteczności na ręcznie oznaczonym zbiorze rzeczywistych psów. Testy syntetyczne sprawdzają działanie treningu, zapisu i oceny, nie trafność biologiczną.

Źródła techniczne: [regresja logistyczna](https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.LogisticRegression.html), [walidacja danych grupowanych](https://scikit-learn.org/stable/modules/cross_validation.html#cross-validation-iterators-for-grouped-data).
