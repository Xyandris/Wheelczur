# Analiza ruchu w Wheelczur 1.1

## Przepływ

1. YOLOX-Tiny wybiera psa, a RTMPose AP-10K zwraca punkty w każdej klatce.
2. Dotychczasowy pipeline zapisuje niezmieniony format CSV z punktami i statusami.
3. `canine_limb.motion` sprawdza CSV, buduje osobne szeregi czasowe kończyn i wyznacza kinematykę.
4. `GaussianPhaseModel` z `canine_limb.temporal` dopasowuje dwu-stanowy gaussowski HMM do szeregu kątów każdej kończyny.
5. CLI zapisuje `*_motion.csv` i `*_motion.json` oraz wypisuje podsumowanie.

Krok 3 można uruchomić niezależnie przez `--analyze TRACKING_CSV`. Nie otwiera on filmu, nie inicjalizuje YOLOX/RTMPose i nie wymaga wag ONNX. Oba sposoby korzystają z tych samych funkcji analizy.

## Model czasowy

Jest to uczenie bez nadzoru na danym nagraniu, osobno dla każdej kończyny. Nie ma zbioru etykiet „zdrowy/chory” ani zewnętrznego checkpointu modelu ruchu. Parametry HMM powstają podczas analizy i są zapisywane w JSON, więc ich dopasowanie można sprawdzić.

- Obserwacja: wygładzony kąt środkowego punktu kończyny, w stopniach.
- Rozkład obserwacji: dwa rozkłady normalne o uczonych średnich i wariancjach.
- Uczenie: EM/Baum–Welch, maksymalnie 40 iteracji, deterministyczna inicjalizacja percentylami.
- Obliczenia: skalowany forward–backward, dekodowanie ścieżki algorytmem Viterbiego.
- Stany: `more_flexed` i `more_extended`, uporządkowane według średniego kąta, zawsze względem zakresu tego nagrania.
- Wariancja ma dolne ograniczenie 1 stopień²; mały prior macierzy przejść premiuje utrzymywanie stanu.
- Każdy brak danych rozpoczyna nową sekwencję. Przejścia przez luki nie są uczone ani dekodowane.

Do uczenia potrzeba co najmniej `max(12, ceil(FPS))` poprawnych klatek w odcinkach długości co najmniej `max(6, round(0.2 * FPS))`. Zakres kątów P95–P05 i różnica średnich stanów muszą wynosić co najmniej 5°. W przeciwnym razie faza pozostaje `unknown`, a raport wyjaśnia przyczynę. Są to progi techniczne modelu, a nie normy fizjologiczne. Pole `converged` informuje, czy osiągnięto kryterium zatrzymania przed limitem iteracji.

`phase_probability` jest prawdopodobieństwem danego stanu według dopasowanego HMM. Nie jest pewnością poprawności pomiaru, kontaktem z podłożem, prawdopodobieństwem choroby ani skalibrowaną oceną zdrowia. Surowe score RTMPose również nie są skalibrowanymi prawdopodobieństwami i mogą przekraczać 1.

## Przygotowanie danych

- Wymagane kolumny: `frame,time_s,limb,joint,x_px,y_px,score,status`.
- Kolejność wierszy nie ma znaczenia. Duplikaty frame/limb/joint, nieznane kończyny i sprzeczne czasy są błędami.
- Do geometrii klatki potrzebne są wszystkie trzy punkty kończyny ze statusem `detected`, skończonym score i współrzędnymi; odcinki o zerowej długości są odrzucane.
- Dodatkowy `--motion-confidence` może odrzucić słabsze wykrycia, ale nie przywraca punktów, które tracker już oznaczył jako brakujące.
- Nie ma interpolacji. Brak punktu lub całej klatki rozdziela odcinki. W CSV wynikowym pozostaje `missing_or_rejected` i puste pola liczbowe; zupełnie nieobecnych wierszy źródła nie dopisuje się do eksportu.
- Domyślne wygładzanie to centrowana średnia ruchoma współrzędnych w oknie około 100 ms, zaokrąglonym do nieparzystej liczby klatek. Na brzegach okno jest skracane, wewnątrz luk nie działa. `--motion-smooth-ms 0` wyłącza filtr.
- FPS jest wyznaczane z czasu i różnic numerów klatek. Nierówne odstępy wymagają poprawienia danych lub świadomego `--fps`. Przy override czas jest liczony jako `frame/FPS`. Jeden wiersz czasu pozwala policzyć kąt, ale nie prędkość ani model czasowy.

## Pomiary i jednostki

| Wynik | Definicja |
| --- | --- |
| `angle_deg` | Kąt między wektorami od łokcia/kolana do barku/biodra i do łapy, 0–180° |
| `angular_velocity_deg_s` | Pochodna kąta względem czasu; różnice centralne wewnątrz odcinka i jednostronne na jego końcach |
| `reference_limb_length_px` | Mediana sumy długości dwóch widocznych odcinków kończyny w poprawnych klatkach, przed wygładzaniem |
| `relative_paw_x/y_limb_lengths` | `(łapa - bark/biodro) / reference_limb_length_px`; x w prawo, y w dół |
| `relative_paw_speed_limb_lengths_s` | Norma pochodnej względnej pozycji łapy, liczona tylko w ciągłych odcinkach |
| `range_p05_p95` | Różnica 95. i 5. percentyla; ogranicza wpływ skrajnych odczytów |
| `relative_paw_path_limb_lengths` | Suma odległości między sąsiednimi poprawnymi klatkami; żadna odległość nie przechodzi przez lukę |
| `coverage` | Udział klatek z pełną geometrią kończyny w zakresie od pierwszej do ostatniej klatki CSV |

Przy pojedynczych, odizolowanych klatkach kąt może być dostępny, a prędkość i droga pozostają puste. `paw_x_px` i `paw_y_px` w nowym CSV to współrzędne po wygładzaniu; oryginalny CSV pozostaje surowym źródłem punktów.

Normalizacja usuwa jednolite przesunięcie obrazu i jednolite przeskalowanie. Nie usuwa obrotu kamery, zmian perspektywy, skrótów perspektywicznych ani obrotu psa. Każda kończyna ma własną długość referencyjną, więc porównanie nie jest pomiarem różnicy długości anatomicznych.

### Powtarzalność

Autokorelacja analizuje względną współrzędną x łapy w najdłuższym ciągłym odcinku. Najpierw usuwa trend liniowy. Szuka lokalnego maksimum o korelacji co najmniej 0,55, w zakresie okresów 0,2–3 s, z co najmniej trzema pełnymi okresami w odcinku. Wybiera pierwszy silny szczyt o co najmniej 90% wartości najlepszego szczytu. Małe wychylenie (odchylenie standardowe poniżej 0,005 długości kończyny) nie daje estymaty.

`complete_periods_in_segment` dotyczy tylko wskazanego odcinka, a nie liczby wszystkich kroków w filmie. Brak wiarygodnej powtarzalności oznacza pusty okres i częstotliwość oraz tekstowy status. Ruch pionowy bez wyraźnej składowej x może nie dać okresu. Ujęcie `test-vid/doggi-walk-01.mp4` ma 114 klatek przy 60 FPS (1,9 s), więc może być zbyt krótkie na trzy pełne powtórzenia.

### Porównanie lewej i prawej strony

Porównywane są przednie lub tylne kończyny na tych samych poprawnych klatkach. Potrzeba co najmniej `max(12, ceil(FPS))` wspólnych klatek i 50% wspólnego pokrycia. Zakresy liczone są ponownie tylko na wspólnych obserwacjach.

Względna różnica to `200 * abs(L - R) / (abs(L) + abs(R))` procent. Dla zerowego mianownika wynik jest pusty. Dla jednej wybranej kończyny status brzmi `both_limbs_required`. Różnica widoczności obu stron i perspektywa mogą wpływać na wynik nawet przy dobrym pokryciu.

## Pliki wynikowe

`*_motion.csv` ma po jednym wierszu na kończynę i obecny w źródle numer klatki. Kolumna `segment` wskazuje niezależny ciąg poprawnych danych. Kolumny fazy są niezależne od `data_status`: poprawna geometria nie gwarantuje wystarczających danych do HMM.

`*_motion.json` zawiera ustawienia, czas, jakość obserwacji, statystyki kończyn, okres, parametry HMM, porównania stron i ograniczenia. Jest ścisłym JSON bez `NaN` i `Infinity`; niedostępne wartości mają `null`. Jakość `usable` oznacza co najmniej sekundę danych i co najmniej 60% pokrycia. Nie jest oceną poprawności klinicznej. Krótsze dane to `insufficient_data`, a słabsze pokrycie to `low_coverage`.

Nowe wyniki powstają w katalogu tymczasowym i są publikowane po poprawnym zakończeniu analizy. Błąd analizy przed publikacją nie nadpisuje wcześniejszych wyników. Każde zastąpienie pliku jest atomowe; cały zestaw kilku plików nie stanowi jednej transakcji systemu plików.

## Ograniczenia i dalszy rozwój

AP-10K w tym projekcie daje tylko trzy punkty na kończynę. Kąt biodro–kolano–łapa jest geometrią tych punktów w obrazie; nie odtwarza wszystkich stawów tylnej kończyny. Z obrazu 2D nie wyznaczamy sił nacisku, pewnego kontaktu z podłożem, dokładnych kątów 3D ani długości w centymetrach.

Najlepsze dane dają kilkusekundowe ujęcia całego psa z boku, przy stałej kamerze, małym zasłanianiu kończyn i poprawnym FPS. Sam HMM nie identyfikuje chodu typu stęp/kłus, choroby ani kulawizny. W wersji 1.2 dodano osobną warstwę uczoną na oznaczonych przykładach do oceny „ruch prawidłowy / nieprawidłowy”. Jej trening, wymagane etykiety i walidację według psów opisano w [TRAINING.md](TRAINING.md). Jest to klasyfikacja względem danych użytkownika, nie diagnoza choroby.

## Źródła techniczne

- [Dokumentacja HMM: forward–backward, Baum–Welch, Viterbi i niezależne sekwencje](https://hmmlearn.readthedocs.io/en/stable/tutorial.html). Implementacja Wheelczura korzysta z NumPy, bez zależności od hmmlearn i bez kopiowania jego kodu.
- [Oficjalny opis punktów AP-10K w MMPose](https://mmpose.readthedocs.io/en/latest/_modules/mmpose/datasets/datasets/animal/ap10k_dataset.html).
