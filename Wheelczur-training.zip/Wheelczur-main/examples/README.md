# Przykład analizy wcześniejszego filmu

`doggi-walk-01_all.csv` to rzeczywisty eksport punktów z dołączonego `test-vid/doggi-walk-01.mp4`, otrzymany przez oryginalne modele YOLOX-Tiny i RTMPose AP-10K. Plik ma 114 klatek przy 60 FPS, cztery kończyny i 1368 obserwacji punktów. Jest przykładem działania aplikacji, a nie ręcznie oznaczonym zbiorem referencyjnym.

Po zainstalowaniu środowiska uruchom z głównego folderu projektu:

```bash
python launcher.py --analyze examples/doggi-walk-01_all.csv
```

Nie trzeba do tego pobierać modeli. Nowe pliki `doggi-walk-01_all_motion.json` i `doggi-walk-01_all_motion.csv` pojawią się w `examples/`.

Jeżeli wyniki już istnieją, użyj bezpośredniego CLI w zainstalowanym środowisku i wskaż nowy katalog:

```bash
python track_limb.py --analyze examples/doggi-walk-01_all.csv --output-dir kolejna_analiza
```

W sprawdzonym uruchomieniu HMM dopasował dwa względne stany dla każdej kończyny. Oszacowanie okresu pozostało niedostępne (`no_reliable_periodicity`): materiał jest krótki i nie spełnił kryterium wiarygodnego powtarzania ruchu. Nie należy utożsamiać tego statusu z brakiem ruchu ani z chorobą. Przykładowych różnic między stronami nie oceniano względem etykiet klinicznych.
