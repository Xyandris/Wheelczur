# Wheelczur

Program do śledzenia kończyn psa i analizy jego ruchu w nagraniach wideo. Wykorzystuje modele YOLOX-Tiny i RTMPose do wyznaczania punktów, czasowy model HMM do opisu względnego zgięcia kończyny oraz **zapisywany klasyfikator uczony na Twoich nagraniach** do oceny „ruch prawidłowy / nieprawidłowy”. Wszystko działa lokalnie, w terminalu.

**Nowość w 1.2:** dodawanie oznaczonych nagrań, trening na całym zbiorze i ocena nowych filmów. W istniejącej instalacji zaktualizuj środowisko opcją **1** (CPU) lub **2** (CUDA), aby zainstalować bibliotekę do treningu.

## 1. Instalacja Pythona

Program działa na Windowsie i Linuxie, wymaga Pythona **3.10–3.13** oraz internetu podczas instalacji.

### Windows

1. Na [python.org](https://www.python.org/downloads/windows/) znajdź **Python 3.13.x** i pobierz **Windows installer (64-bit)**.
2. Uruchom instalator, zaznacz **Add python.exe to PATH** i kliknij **Install Now**. Narzędzie `pip` zainstaluje się razem z Pythonem.
3. Otwórz nowe okno PowerShell i sprawdź instalację:

```powershell
python --version
python -m pip --version
```

Pierwsze polecenie powinno wyświetlić wersję `3.13.x`.

### Linux (Ubuntu 24.04 LTS / Debian 13)

Otwórz terminal i zainstaluj Pythona, `pip` oraz obsługę środowisk wirtualnych:

```bash
sudo apt update
sudo apt install python3 python3-pip python3-venv
python3 --version
```

Wersja musi mieścić się w zakresie **3.10–3.13**. W dalszych poleceniach na Linuxie używaj **`python3` zamiast `python`**. Na innych dystrybucjach zainstaluj zgodną wersję Pythona i moduł `venv` przez menedżer pakietów systemu.

## 2. Instalacja programu

Na GitHubie wybierz **Code → Download ZIP** i rozpakuj archiwum. Otwórz terminal w folderze zawierającym `launcher.py` i wykonaj kolejno:

```bash
python launcher.py --setup cpu
python launcher.py --models
```

Pierwsze polecenie tworzy środowisko `.venv-cpu` i instaluje wszystkie wymagane pakiety, w tym `numpy` i `opencv-python-headless`. Drugie pobiera i sprawdza modele. Nie trzeba ręcznie aktywować środowiska.

### Błąd certyfikatu przy pobieraniu modeli (Windows)

Jeśli przy pobieraniu modeli pojawi się `CERTIFICATE_VERIFY_FAILED` lub `unable to get local issuer certificate`, spróbuj poniższego rozwiązania. Wyjdź z menu launchera opcją **0**, jeśli jest otwarte. Następnie w terminalu, w folderze projektu, wykonaj kolejno:

```bat
python -m pip install --upgrade truststore
python -c "import truststore; truststore.inject_into_ssl(); import download_models; raise SystemExit(download_models.main())"
```

**Wykonaj obie komendy** — druga uruchamia pobieranie z użyciem certyfikatów systemowych. Samo zainstalowanie `truststore` nie zmienia działania opcji 7 w launcherze.

Po komunikacie **Oba modele są gotowe** uruchom ponownie `python launcher.py` i kontynuuj pracę z menu.

## 3. Użycie

```bash
python launcher.py --run cpu
```

1. Podaj ścieżkę do filmu, np. `test-vid/doggi-walk-01.mp4`.
2. Wybierz kończynę z listy lub `all`, aby śledzić wszystkie. Lewa i prawa strona odnoszą się do stron psa.
3. Poczekaj na zakończenie analizy.

Wyniki znajdziesz obok filmu, w folderze `<nazwa_filmu_bez_rozszerzenia>_tracking/`:

- **CSV** — współrzędne punktów, czas i pewność wykrycia.
- **MP4** — film z zaznaczonymi punktami i połączeniami.
- **JSON** — ustawienia i podsumowanie analizy.
- **`*_motion.csv`** — kąty, prędkości i faza ruchu dla każdej klatki i kończyny.
- **`*_motion.json`** — zakres ruchu, powtarzalność, porównanie stron, jakość danych i parametry dopasowanego HMM.

### Obsługa przez menu tekstowe

Po zainstalowaniu Pythona możesz wykonać wszystkie kroki z menu tekstowego. W folderze projektu wystarczy uruchomić:

```bash
python launcher.py
```

Menu umożliwia instalację pakietów, pobranie modeli, analizę na CPU/GPU oraz sprawdzenie środowiska. Wpisz numer wybranej opcji i zatwierdź klawiszem **Enter**. Przy pierwszym użyciu na CPU wybierz kolejno **1 → 7 → 3**.

## 4. Analiza ruchu

Po zakończeniu śledzenia program automatycznie analizuje zapisane punkty. Wybierz **`all`**, jeżeli chcesz porównać lewą i prawą stronę psa. Przy jednej kończynie nadal otrzymasz jej kąty, prędkości, oszacowanie okresu powtarzania ruchu oraz fazy HMM.

### Film przeanalizowany wcześniej

Do ponownej analizy służy oryginalny CSV z punktami, nie film z narysowanymi znacznikami ani `*_motion.csv`. Nie trzeba ponownie przetwarzać filmu ani pobierać wag ONNX. Wystarczy istniejące środowisko CPU lub CUDA:

```bash
python launcher.py --analyze "sciezka/do/filmu_all.csv"
```

Do szybkiego sprawdzenia dodano gotowy eksport: `python launcher.py --analyze examples/doggi-walk-01_all.csv`. Pochodzi z krótkiego filmu już znajdującego się w projekcie; zobacz [examples/README.md](examples/README.md).

Możesz też uruchomić `python launcher.py` i wybrać nową opcję **9**. Program poprosi o ścieżkę CSV i wypisze wyniki w terminalu. Analiza danych działa na CPU także w środowisku CUDA; nie wymaga do tego działającej karty NVIDIA.

Zaawansowane opcje są dostępne bezpośrednio w CLI aplikacji. Uruchom je Pythonem ze swojego środowiska; na Windowsie użyj `.venv-cpu\Scripts\python.exe`, a na Linuxie `.venv-cpu/bin/python`:

```bash
# Nowy film: punkty, film z oznaczeniami oraz automatyczna analiza ruchu
python track_limb.py "film.mp4" --limb all --device cpu

# Samodzielna analiza wcześniejszego CSV do osobnego katalogu
python track_limb.py --analyze "film_all.csv" --output-dir "analiza_ruchu"

# Opcjonalne wygładzanie i dodatkowy próg jakości punktów
python track_limb.py --analyze "film_all.csv" --motion-smooth-ms 100 --motion-confidence 0.4

# Korekta czasu, gdy znasz właściwe FPS nagrania
python track_limb.py --analyze "film_all.csv" --fps 60 --output-dir "analiza_60fps"

# Dotychczasowy eksport bez nowej analizy ruchu
python track_limb.py "film.mp4" --limb left-hind --no-motion
```

Istniejące wyniki są chronione przed nadpisaniem. W bezpośrednim CLI można użyć `--overwrite` albo wskazać inny `--output-dir`. W launcherze opcja 9 nie nadpisuje wyników; jeśli już istnieją, CLI wyjaśni, jak wykonać analizę w innym katalogu.

### Co oznacza wynik

- **Kąty**: kąt bark–łokieć–łapa lub biodro–kolano–łapa w obrazie 2D; raport podaje m.in. zakres między 5. a 95. percentylem.
- **Prędkość łapy**: względem barku/biodra, w długościach widocznej kończyny na sekundę. Jednolite przesunięcie psa i zmiana skali obrazu nie zmieniają tej miary. Program nie podaje metrów na sekundę bez kalibracji.
- **Powtarzalność**: okres i częstotliwość powtarzania ruchu łapy, jeśli w jednym ciągłym odcinku widać co najmniej trzy wiarygodne powtórzenia. To nie jest liczba wszystkich kroków psa.
- **Model HMM**: uczy się dwóch względnych pozycji kończyny w danym nagraniu (`more_flexed`, `more_extended`). Jego parametry i wewnętrzne prawdopodobieństwa stanów trafiają do raportu. Model nie określa kontaktu łapy z podłożem.
- **Porównanie stron**: różnice zakresu kątów i wychylenia łap na wspólnych, poprawnie wykrytych klatkach. Różnica nie jest rozpoznaniem choroby.

Brakujące lub odrzucone punkty pozostają brakami; analiza nie wstawia zgadywanych współrzędnych. Krótkie, zasłonięte i nieruchome ujęcia mogą nie wystarczyć do dopasowania HMM lub oszacowania okresu. Dokładne zasady, format raportu i ograniczenia opisano w [docs/MOTION.md](docs/MOTION.md), a analizę projektu i zakres zmian w [ANALIZA_I_ZMIANY.md](ANALIZA_I_ZMIANY.md).

Opisany w tej sekcji HMM korzysta z NumPy i nie wymaga dodatkowych wag. Uczy się lokalnych faz danego nagrania. Osobny, zapisywany klasyfikator „prawidłowy / nieprawidłowy” opisano poniżej; do jego treningu instalator dodaje scikit-learn.

## 5. Uczenie: ruch prawidłowy / nieprawidłowy

Uruchom `python launcher.py`. Nowe opcje menu:

| Opcja | Co robisz |
| --- | --- |
| **10** | Dodajesz film lub oryginalny CSV z punktami, wybierasz etykietę i podajesz ID psa |
| **11** | Uczysz model na wszystkich dotychczasowych przykładach; program sam zapisuje `gait_model.json` |
| **12** | Podajesz nowy film lub CSV; program wypisuje **RUCH PRAWIDŁOWY** albo **RUCH NIEPRAWIDŁOWY** |

Dodaj co najmniej **dwa różne nagrania w każdej klasie**; to minimum techniczne do uruchomienia prototypu. Używaj tego samego ID dla wszystkich filmów tego samego psa. Wybieraj zgodne kończyny, np. `all` podczas dodawania i treningu. Do modelu jednej kończyny możesz wykorzystać swoje wcześniejsze CSV: wybierz np. `left-fore` przy dodawaniu i treningu. Podczas oceny program odczytuje wybraną kończynę z zapisanego modelu.

Bez menu:

```bash
python launcher.py --add-sample "filmy/dobry_01.mp4" --label prawidlowy --dog-id pies01
python launcher.py --add-sample "filmy/zly_01.mp4" --label nieprawidlowy --dog-id pies02
# Dodaj kolejne, różne nagrania: minimum dwa w każdej klasie.
python launcher.py --train
python launcher.py --predict "filmy/nowy_film.mp4"
```

Kolejne filmy dodajesz opcją 10, a potem ponownie wybierasz 11. Model zostaje przeliczony z całego zbioru i zapisany na następne uruchomienia. Nie trzeba otwierać JSON-a ani ręcznie wpisywać parametrów. Po treningu zwykłe śledzenie (3/4) i analiza CSV (9) również dopisują ocenę, gdy dane obejmują kończyny wymagane przez model.

Przy zbyt słabych danych lub niepewnej decyzji program wypisze **BRAK OCENY** wraz z przyczyną. Ocenia wzorzec nauczony z Twoich oznaczeń; nie zastępuje diagnozy weterynaryjnej. W archiwum nie ma udawanego modelu wytrenowanego na nieoznaczonych filmach. Dokładny przebieg i przykłady dla pojedynczej kończyny: [docs/TRAINING.md](docs/TRAINING.md).

## Opcjonalnie: karta NVIDIA (CUDA)

Po pobraniu modeli zamiast poleceń CPU użyj:

```bash
python launcher.py --setup cuda
python launcher.py --run cuda
```

Instalator automatycznie doda `onnxruntime-gpu` z bibliotekami CUDA/cuDNN. Wymagana jest karta NVIDIA z odpowiednim sterownikiem, a w Windows także Visual C++ x64 Runtime.
